'use strict';

describe('test messageSvc', function () {
    beforeEach(module('loyakk-services'));
    // instantiate service
    var messageSvc, appSvc, conversationSvc;
    beforeEach(inject(function (_messageSvc_, _appSvc_, _conversationSvc_) {
        messageSvc = _messageSvc_;
        appSvc = _appSvc_;
        conversationSvc = _conversationSvc_;

    }));

////    //TESTING ADD TO CONVERSATIONS
////    it('test add to conversation', function () {
////        var nickname = '';
////        var userId = '';
////        runs(function () {
////            appSvc.autoLogin().then(function (data) {
////                userId = data.userId;
////                nickname = data.nickname;
////            });
////        });
////        waits(2000);
////        runs(function () {
////            var msg = "random_" + Math.random();
////            messageSvc.addToConversation(159427, {message: msg, userid: userId, nickname: nickname}).then(function (data) {
////                conversationSvc.getChannelConversations(159427, {maxCount: 1}).then(function (conversations) {
////                        expect(conversations[0].description).toBe(msg);
////                    }, function () {
////                        expect('FAILED').toBe("SUCCESS");
////                    }
////                );
////            });
////
////        }, function () {
////            expect('FAILED').toBe("SUCCESS");
////        });
////
////        waits(5000);
////    });
////
////
////    //TESTING LIKE MESSAGES
////    it('test like message', function () {
////        var nickname = '';
////        var userId = '';
////        runs(function () {
////            appSvc.autoLogin().then(function (data) {
////                userId = data.userId;
////                nickname = data.nickname;
////            });
////        });
////        waits(2000);
////        runs(function () {
////            var msg = "random_" + Math.random();
////            messageSvc.addToConversation(159427, {message: msg, userid: userId, nickname: nickname}).then(function (data) {
////                // The numLikes should be zero before  like
////                messageSvc.getMessageDetails(data.messageId).then(function (data) {
////                    expect(data.numLikes).toBe(0);
////                }, function () {
////                    expect('FAILED').toBe("SUCCESS");
////                });
////                messageSvc.like(data.messageId, userId, channelId, {userid: userId, nickname: nickname}).then(function () {
////                    // The numLikes should be one after  like
////                    messageSvc.getMessageDetails(data.messageId).then(function (data) {
////                        expect(data.numLikes).toBe(1);
////                    }, function () {
////                        expect('FAILED').toBe("SUCCESS");
////                    });
////                    // expect(message.numLikes).toBe(true);
////                }, function () {
////                    expect('FAILED').toBe("SUCCESS");
////                });
////                // Second like from same user for same message should fail.
////                messageSvc.like(data.messageId, userId, channelId, {userid: userId, nickname: nickname}).then(function () {
////                    messageSvc.getMessageDetails(data.messageId).then(function (data) {
////                        //expect(data.numLikes).toBe(1);
////                    }, function () {
////                        expect('FAILED').toBe("SUCCESS");
////                    });
////                    // expect(message.numLikes).toBe(true);
////                }, function () {
////                    expect('FAILED').toBe("FAILED");
////                });
////            });
////        });
////        waits(5000);
////    });
////    //TESTING SPAM MESSAGES
////    it('test spam message', function () {
////        var nickname = '';
////        var userId = '';
////        runs(function () {
////            appSvc.autoLogin().then(function (data) {
////                userId = data.userId;
////                nickname = data.nickname;
////            });
////        });
////        waits(2000);
////        runs(function () {
////            var msg = "random_" + Math.random();
////            messageSvc.addToConversation(11147, {message: msg, userid: userId, nickname: nickname}).then(function (data) {
////                // The spamCount should be zero before  like
////                messageSvc.getMessageDetails(data.messageId).then(function (data) {
////                    expect(data.spamCount).toBe(0);
////                }, function () {
////                    expect('FAILED').toBe("SUCCESS");
////                });
////                messageSvc.spam(data.messageId, userId, {userid: userId, nickname: nickname}).then(function () {
////                    // The spamCount should be one after  like
////                    messageSvc.getMessageDetails(data.messageId).then(function (data) {
////                        expect(data.spamCount).toBe(1);
////                    }, function () {
////                        expect('FAILED').toBe("SUCCESS");
////                    });
////                    // expect(message.spamCount).toBe(true);
////                }, function () {
////                    expect('FAILED').toBe("SUCCESS");
////                });
//                // Second spamCount from same user for same message should fail.
////                messageSvc.spam(data.messageId, userId, {userid: userId, nickname: nickname}).then(function () {
////                    messageSvc.getMessageDetails(data.messageId).then(function (data) {
////                        //expect(data.spamCount).toBe(1);
////                    }, function () {
////                        expect('FAILED').toBe("SUCCESS");
////                    });
////                    // expect(message.spamCount).toBe(true);
////                }, function () {
////                    expect('FAILED').toBe("FAILED");
////                });
//            });
//        });
//        waits(5000);
//    });
//                                                       s
    //TESTING get MESSAGES
    it('test getMessages', function () {
        waits(2000);
        messageSvc.getMessages(11147).then(function (messages) {
            expect(messages.length).toBe(1);
        }, function () {
            expect('FAILED').toBe("SUCCESS")
        });
    });

    // Testing  sending, getting, marking, counting  private message
//
//    it('test sending private message', function(){
//        var nickname = '';
//        var userId = '';
//        runs(function () {
//            appSvc.autoLogin().then(function (data) {
//                userId = data.userId;
//                nickname = data.nickname;
//            });
//        });
//        waits(2000);
//        messageSvc.sendPrivateMessage(11147, {fromUserId: 1234 , toUserId: 4567 , message: "hello how r u ?", userid: userId, nickname: nickname}).then(function (data){
//             expect(data).toBe(true);
//        }, function(){
//            expect('FAILED').toBe("SUCCESS");
//        });
//    });

    //Testing delete message

    it('test deleting message', function () {
        var nickname = '';
        var userId = '';
        runs(function () {
            appSvc.autoLogin().then(function (data) {
                userId = data.userId;
                nickname = data.nickname;
                console.log(userId);
                console.log(nickname);
            });
        });
        waits(2000);
        var msg = "random_" + Math.random();
        messageSvc.addToConversation(159427, {message: msg, userid: userId, nickname: nickname}).then(function (data) {
            messageSvc.deleteMessage(userId, data.messageId, {userid: userId, nickname: nickname}).then(function (data) {
                expect(data).toBe(true);
            }, function () {
                expect('FAILED').toBe("SUCCESS");
            });
        });
    });

});

