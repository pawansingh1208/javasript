'use strict';

describe('test conversationSvc', function () {

    beforeEach(module('loyakk-services'));

    var conversationSvc, appSvc;
    beforeEach(inject(function (_conversationSvc_, _appSvc_) {
        conversationSvc = _conversationSvc_;
        appSvc = _appSvc_;

    }));

//    it('test popular conversation', function(){
//        waits(2000);
//        conversationSvc.getPopularConversations({maxCount: 6}).then(function (conversations) {
//                expect(conversations.length).toBe(6);
//            }, function () {
//                expect('FAILED').toBe("SUCCESS");
//            });
//
//        conversationSvc.getPopularConversations({maxCount: 20}).then(function (conversations) {
//            expect(conversations.length).toBe(20);
//        }, function () {
//            expect('FAILED').toBe("SUCCESS");
//        });
//
//    });
//
//    it('test channel conversation', function(){
//        waits(2000);
//        conversationSvc.getChannelConversations(159427, {maxCount: 6}).then(function(conversations){
//                expect(conversations.length).toBe(6);
//            },function(){
//                expect('FAILED').toBe("SUCCESS");
//            });
//    });

//    it('test add new conversation', function(){
//        var nickname = '';
//        var userId = '';
//        runs(function () {
//            appSvc.autoLogin().then(function(data){
//                  userId = data.userId;
//                  nickname = data.nickname;
//            });
//        });
//        waits(2000);
//        runs(function() {
//            var msg = "random_" + Math.random();
//            conversationSvc.addNewConversation(159427, {message: msg, userid: userId, nickname: nickname}).then(function(data){
//                conversationSvc.getChannelConversations(159427, {maxCount: 1}).then(function(conversations){
//                   expect(conversations[0].description).toBe(msg);
//                });
//
//            },function(){
//                expect('FAILED').toBe("SUCCESS");
//            });
//        });
//        waits(5000);
//
//    });

//    it('test private conversation', function () {
//        var nickname = '';
//        var userId = '';
//        runs(function () {
//            appSvc.autoLogin().then(function (data) {
//                userId = data.userId;
//                nickname = data.nickname;
//            });
//        });
//        waits(2000);
//        runs(function () {
//            conversationSvc.getPrivateConversations(userId, {maxCount: 6, userid: userId, nickname: nickname}).then(function (conversations) {
//                expect(conversations.length).toBe(6);
//            }, function () {
//                expect('FAILED').toBe("SUCCESS");
//            });
//        });
//        waits(5000);
//
//    });

//    it('test public conversation', function () {
//        var nickname = '';
//        var userId = '';
//        runs(function () {
//            appSvc.autoLogin().then(function (data) {
//                userId = data.userId;
//                nickname = data.nickname;
//            });
//        });
//        waits(2000);
//        runs(function () {
//            conversationSvc.getPublicConversations(userId, {maxCount: 1, userid: userId, nickname: nickname}).then(function (conversations) {
//                expect(conversations.length).toBe(1);
//            }, function () {
//                expect('FAILED').toBe("SUCCESS");
//            });
//        });
//        waits(5000);
//
//    });

//    it('test nearBy conversation', function () {
//        waits(2000);
//        conversationSvc.getNearbyConversations({maxCount: 6, latitude: 37.343427, longitude: -122.030501}).then(function (conversations) {
//            expect(conversations.length).toBe(6);
//        }, function () {
//            expect('FAILED').toBe("SUCCESS");
//        });
//
//        waits(5000);
//
//    });
//
//    it('test nearBy conversation', function () {
//        waits(2000);
//        conversationSvc.getVenueConversations(38383).then(function (conversations) {
//            expect(conversations.length).toBe(6);
//        }, function () {
//            expect('FAILED').toBe("SUCCESS");
//        });
//
//        waits(5000);
//
//    });
    it('test privateChannelConversation', function () {
        waits(2000);
        conversationSvc.getPrivateChannelConversation(11583,1099847 ).then(function (conversations) {
            expect(conversations.length).toBe(6);
        }, function () {
            expect('FAILED').toBe("SUCCESS");
        });

        waits(5000);

    });

});