angular.module('loyakk-services').factory('userSvc', function ($rootScope, appSvc, $http, $q) {
    var svc = {
        maxCount: 20,
        getQueryVariable: function (variable) {
            var query = window.location.search.substring(1);
            var vars = query.split('&');

            for (var i = 0; i < vars.length; i++) {
                var pair = vars[i].split('=');
                if (decodeURIComponent(pair[0]) == variable) {
                    return decodeURIComponent(pair[1]);
                }
            }
            console.log('Query variable %s not found', variable);
        },

        isNickNameAvailable: function (nickName) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrl + 'nickname/' + nickName;
            $http.get(api_url).success(function (data,status) {
                deferred.resolve(data);
            }).error(function (data) {
//                    console.log(data);
                    deferred.resolve(data);
                });
            return deferred.promise;
        },

        registerNickName: function (params) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrlSecure + 'users/register';
            $http.post(api_url, params).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
//                    console.log(data);
                    deferred.resolve(data);
                });
            return deferred.promise;
        },

        //login service where params are nickname and password as request and response is [{"userId":"<<userId>>", "authenToken":"<<authenToken>>", "mediaList":[{"type":"jpeg","keyname":"user_1","category":"fullsize"}]"
        login: function(params) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrlSecure + 'users/login';
            $http.put(api_url, params).success(function(data){
                $http.defaults.headers.common = {
                    'Authorization': 'Basic ' + data.authenToken,
                    'Content-Type': 'application/json'
                };
                svc.authorizationHeader = 'Basic ' + data.authenToken;
                deferred.resolve(data);
            }).error(function(data){
//                    console.log(data);
                deferred.resolve(data);
            });
            return deferred.promise;
        },

        //params as request(emailid)
        forgotPassword: function(params) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrl + 'users/forgotpass';
            $http.put(api_url, params).success(function(data){
                deferred.resolve(data);
            }).error(function(data){
                    deferred.resolve(data);
            });
            return deferred.promise;
        },

        //reset password
        resetPassword: function(resetToken) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrl + 'users/'+ resetToken +'/resetpass';
            $http.put(api_url).success(function(data){
                deferred.resolve(data);
            }).error(function(data){
                deferred.reject();
            });
            return deferred.promise;
        },

        //Request: {"userId(mendatory)":"1234","newNickname":"joedoe","newEmail":"joedoe@gmail.com","messageNotfApp":true,"messageNotfEmail":false, "profileDescription":"Test profile", "firstName":"John", "lastName":"Doe"}
        editUserProfile: function(params) {
            var deferred = $q.defer();
            var api_url =  appSvc.baseUrlSecure + 'users/editprofile';
            $http.put(api_url,params).success(function(data){
                deferred.resolve(data);
            }).error(function(data){
                deferred.reject();
            });
            return deferred.promise;
        },

        //Request:{"userId":"<<userId>>","oldPassword":"<<oldPassword>>","newPassword":"<<newPassword>>"} Response:  {"userId":"<<userId>>", "authenToken":"<<authenToken>>"}
        ChangePassword: function(params) {
            var deferred = $q.defer();
            var api_url =  appSvc.baseUrlSecure + 'users/changepass';
            $http.put(api_url,params).success(function(data){
                deferred.resolve(data);
            }).error(function(data){
                deferred.resolve(data);
            });
            return deferred.promise;
        },

        //get user info
        getUserInfo: function(userId) {
            var deferred = $q.defer();
            var api_url =  appSvc.baseUrlSecure + 'users/' + userId + '/info';
            $http.get(api_url).success(function(data){
                deferred.resolve(data);
            }).error(function(data){
                deferred.reject();
            });
            return deferred.promise;
        },

        //get email by nickname
        getEmailByNickname: function(nickName){
            var deferred = $q.defer();
            var api_url = appSvc.baseUrl + 'nickname/email/'+ nickName;
            $http.get(api_url).success(function(data){
                deferred.resolve(data);
            }).error(function(data){
                deferred.reject();
            });
            return deferred.promise;
        } ,

        //get public user info
        getPublicUserInfo: function(userId) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrl + 'users/'+ userId + '/publicinfo';
            $http.get(api_url).success(function(data){
                deferred.resolve(data);
            }).error(function(data){
                    deferred.reject();
                });
            return deferred.promise;
        },
        getUserPosts: function(userId) {
        	var deferred = $q.defer();
            var api_url = appSvc.baseUrlSecure + 'conversations/user/'+ userId + '/private';
     		$http.get(api_url).success(function(data){
     			deferred.resolve(data);
     		}).error(function(data){
     			deferred.reject();
     		});
     		return deferred.promise;
       },
       MyInbox: function(userId){
       		var deferred = $q.defer();
            var api_url = appSvc.baseUrlSecure + 'users/'+ userId + '/newmessagecount';
            $http.get(api_url).success(function(data){
            	deferred.resolve(data);
            }).error(function(data){
            	deferred.reject();
            });
            return deferred.promise;
       }
		
    };
    return svc;
});
