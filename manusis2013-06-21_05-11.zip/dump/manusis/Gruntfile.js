'use strict';
var lrSnippet = require('grunt-contrib-livereload/lib/utils').livereloadSnippet;
var mountFolder = function (connect, dir) {
  return connect.static(require('path').resolve(dir));
};

module.exports = function (grunt) {
  // load all grunt tasks
  require('matchdep').filterDev('grunt-*').forEach(grunt.loadNpmTasks);

  // configurable paths
  var yeomanConfig = {
    app: 'app',
    dist: 'dist'
  };

  try {
    yeomanConfig.app = require('./component.json').appPath || yeomanConfig.app;
  } catch (e) {}

  grunt.initConfig({
    yeoman: yeomanConfig,
    watch: {
      coffee: {
        files: ['<%= yeoman.app %>/scripts/{,*/}*.coffee'],
        tasks: ['coffee:dist']
      },
      coffeeTest: {
        files: ['test/spec/{,*/}*.coffee'],
        tasks: ['coffee:test']
      },
      compass: {
        files: ['<%= yeoman.app %>/styles/{,*/}*.{scss,sass}'],
        tasks: ['compass']
      },
      livereload: {
        files: [
          '<%= yeoman.app %>/{,*/}*.html',
          '{.tmp,<%= yeoman.app %>}/styles/{,*/}*.css',
          '{.tmp,<%= yeoman.app %>}/scripts/{,*/}*.js',
          '<%= yeoman.app %>/images/{,*/}*.{png,jpg,jpeg,gif,webp,svg}'
        ],
        tasks: ['livereload']
      }
    },
    connect: {
      options: {
        port: 7000,
        // Change this to '0.0.0.0' to access the server from outside.
        hostname: 'localhost'
      },
      livereload: {
        options: {
          middleware: function (connect) {
            return [
              lrSnippet,
              mountFolder(connect, '.tmp'),
              mountFolder(connect, yeomanConfig.app)
            ];
          }
        }
      },
      test: {
        options: {
          middleware: function (connect) {
            return [
              mountFolder(connect, '.tmp'),
              mountFolder(connect, 'test')
            ];
          }
        }
      }
    },
    open: {
      server: {
        url: 'http://localhost:<%= connect.options.port %>'
      }
    },
    clean: {
      dist: {
        files: [{
          dot: true,
          src: [
            '.tmp',
            '<%= yeoman.dist %>/*',
            '!<%= yeoman.dist %>/.git*'
          ]
        }]
      },
      server: '.tmp'
    },
    /*jshint: {
      options: {
        jshintrc: '.jshintrc'
      },
      all: [
        'Gruntfile.js',
        '<%= yeoman.app %>/scripts/{,}*.js'
      ]
    },*/
    karma: {
      unit: {
        configFile: 'karma.conf.js',
        singleRun: true
      }
    },
    coffee: {
      dist: {
        files: [{
          expand: true,
          cwd: '<%= yeoman.app %>/scripts',
          src: '{,*/}*.coffee',
          dest: '.tmp/scripts',
          ext: '.js'
        }]
      },
      test: {
        files: [{
          expand: true,
          cwd: 'test/spec',
          src: '{,*/}*.coffee',
          dest: '.tmp/spec',
          ext: '.js'
        }]
      }
    },
    compass: {
      options: {
        sassDir: '<%= yeoman.app %>/styles',
        cssDir: '.tmp/styles',
        imagesDir: '<%= yeoman.app %>/images',
        javascriptsDir: '<%= yeoman.app %>/scripts',
        fontsDir: '<%= yeoman.app %>/styles/fonts',
        importPath: '<%= yeoman.app %>/components',
        relativeAssets: true
      },
      dist: {},
      server: {
        options: {
          debugInfo: true
        }
      }
    },
   /*concat: {
    options: {
      separator: ';'
    },
    dist: {
      src: ['app/scripts/vendor/jquery.jscrollpane.min.js','app/scripts/vendor/jquery.mousewheel.js','app/scripts/controllers/web-app-controller.js','app/scripts/controllers/user-controller.js','app/scripts/loyakk-venue-service.js','app/scripts/loyakk-channel-services.js','app/scripts/loyakk-conversation-service.js','app/scripts/loyakk-message-services.js','app/scripts/loyakk-user-service.js','app/scripts/loyakk-filters.js'],
      dest: 'app/scripts/Dist/app.js'
    }
  },*/
concat: {
    options: {
      separator: ';'
    },
    dist: {
      src: ['app/scripts/vendor/jquery.js','app/scripts/vendor/jquery.prettyPhoto.js',
          'app/scripts/vendor/custom.modernizr.js','app/scripts/vendor/app.js','app/scripts/vendor/fileupload.js',
          'app/scripts/vendor/angular.min.js','app/scripts/vendor/accordian_menu.js','app/scripts/vendor/angular-mocks.js'],
        dest: 'app/scripts/appvendor_<%= appVersion %>.js'
    }
},
 //  useminPrepare: {
   //   html: '<%= yeoman.app %>/index.html',
 //    options: {
  //      dest: '<%= yeoman.dist %>'
 //     }
 //   },
 //   usemin: {
 //    html: ['<%= yeoman.dist %>/{,*/}*.html'],
  //   css: ['<%= yeoman.dist %>/styles/{,*/}*.css'],
  //    options: {
  //      dirs: ['<%= yeoman.dist %>']
 //     }
 //   },
    imagemin: {
      dist: {
        files: [{
          expand: true,
          cwd: '<%= yeoman.app %>/images',
          src: '{,*/}*.{png,jpg,jpeg}',
          dest: '<%= yeoman.dist %>/images'
        }]
      }
    },
    cssmin: {
      dist: {
        files: {
          '<%= yeoman.dist %>/styles/main.css': [
            '.tmp/styles/{,*/}*.css',
            '<%= yeoman.app %>/styles/{,*/}*.css'
          ]
        }
      }
    },
    htmlmin: {
      dist: {
        options: {
          /*removeCommentsFromCDATA: true,
          // https://github.com/yeoman/grunt-usemin/issues/44
          //collapseWhitespace: true,
          collapseBooleanAttributes: true,
          removeAttributeQuotes: true,
          removeRedundantAttributes: true,
          useShortDoctype: true,
          removeEmptyAttributes: true,
          removeOptionalTags: true*/
        },
        files: [{
          expand: true,
          cwd: '<%= yeoman.app %>',
          src: ['*.html', 'views/*.html'],
          dest: '<%= yeoman.dist %>'
        }]
      }
    },
    cdnify: {
      dist: {
        html: ['<%= yeoman.dist %>/*.html']
      }
    },
    ngmin: {
      dist: {
        files: [{
          expand: true,
          cwd: '<%= yeoman.dist %>/scripts',
          src: '*.js',
          dest: '<%= yeoman.dist %>/scripts'
        }]
      }
    },
    uglify: {
      dist: {
        files: {
          '<%= yeoman.dist %>/scripts/scripts.js': [
            '<%= yeoman.dist %>/scripts/scripts.js'
          ]
        }
      }
    },
    rev: {
      dist: {
        files: {
          src: [
            '<%= yeoman.dist %>/scripts/{,*/}*.js',
            '<%= yeoman.dist %>/styles/{,*/}*.css',
            '<%= yeoman.dist %>/images/{,*/}*.{png,jpg,jpeg,gif,webp,svg}',
            '<%= yeoman.dist %>/styles/fonts/*'
          ]
        }
      }
    },


deploy: {
    your_target: {
      options: {
        url: 'https://github.com/pawansingh1208/javasript.git'
      },
      src: 'app/scripts/vendor/*'
    }
  },

 htmlrefs: {
      dist: {
        /** @required  - string including grunt glob variables */
        src: 'app/index.html',
        /** @optional  - string directory name*/
        dest: 'app/'

      }
    },

  ver: {
    options: {
      sort: 'commits',
     id: true,
      nomerges: true,
      output: 'CONTRIBUTIONS.md'
    }
  },
      link_html: {
          your_target: {
              // Target-specific file lists and/or options go here.
              jsFiles: ['app/scripts/builtfoundation_<%= appVersion %>.js'] ,
             // cssFiles: ['path/to/css/files.css'],
              targetHtml: ['app/index.html'],
              options: {
                  cwd: 'public'
              }
          }
      },

      gitco: {
          branch:'master',

repo :'git@github.com:pawansingh1208/javasript.git'

      },


      copy: {
      dist: {
        files: [{
          expand: true,
          dot: true,
          cwd: '<%= yeoman.app %>',
          dest: '<%= yeoman.dist %>',
          src: [
            '*.{ico,txt}',
            '.htaccess',
            'components/**/*',
            'images/{,*/}*.{gif,webp}',
            'styles/fonts/*'
          ]
        }]
      }
    }
  });


  var _ = grunt.util._;
    var exec = require('child_process').exec;

    grunt.registerTask('ver', 'Get the latest commit id from a git repository', function () {
        var options = this.options({
//      sort: 'chronological', // alphabetical, commits
            id: false, // show emails in the output
            nomerges: false, // only works when sorting by commits
            output: './AUTHORS.txt' // the output file
        });

        var done = this.async();

        var _format = function (stdout) {
            var maxcol = 0;
            var pad = ' ';
            return stdout.replace(/^\s+|\s+$/g, '').split('\n').map(function (l) {
                var numl = l.match(/\d+/);
                if (numl) {
                    numl = numl[0].length;
                    maxcol = numl > maxcol ? numl : maxcol;
                    pad = '  ' + new Array(maxcol-numl+1).join(' ');
                }
                return _.trim(l.replace(/\t+/, pad));
            });
        };

        // sort types
        var sortMethod = {
            alphabetical: 'sort',
            chronological: 'reverse'
        };

        // sort output
        var _sort = function (stdout) {
            if (sortMethod[options.sort]) {
                stdout = _.unique(stdout[sortMethod[options.sort]]());
            }
            return stdout;
        };

        // default command 'git'
        var cmd = 'git';
        // show commit id
        if (options.id) {
            cmd += ' --git-dir=loyakk-webapp2/.git rev-parse --short HEAD';
        }

        cmd += '';

        exec(cmd, function (error, stdout, stderr) {
            if (!error) {
                stdout = _format(stdout);
                stdout = _sort(stdout);
                grunt.log.write( stdout.join('\n'));
                var a = stdout.join('\n');
                grunt.config.set('appVersion' , a);
                done();

grunt.task.run('concat');
            } else {
                grunt.fail.warn(error);
            }
        });
    });

  grunt.renameTask('regarde', 'watch');
grunt.loadNpmTasks('grunt-deploy');
grunt.loadNpmTasks('grunt-htmlrefs');
grunt.loadNpmTasks('grunt-git-committers');
grunt.loadNpmTasks('grunt-git_ftp');
grunt.loadNpmTasks('grunt-link-html');
    grunt.loadNpmTasks('grunt-gitco');
  grunt.registerTask('server', [
    'clean:server',
    'coffee:dist',
    'compass:server',
    'livereload-start',
    'connect:livereload',
    'open',
    'watch'
  ]);

  grunt.registerTask('test', [
    'clean:server',
    'coffee',
    'compass',
    'connect:test',
    'karma'
  ]);

  grunt.registerTask('build', [
    'clean:dist',
    //'jshint',
    'test',
    'coffee',
    'compass:dist',
    'useminPrepare',
    'imagemin',
    'cssmin',
    'htmlmin',
    'concat',
    'copy',
    'cdnify',
    'ngmin',
    'uglify',
    'rev',
    'usemin'
  ]);

  grunt.registerTask('default', ['build','deploy','concat','htmlrefs','ver','git_ftp',' link_html','gitco']);
};
