<?php

echo "/usr/local/bin/phantomjs " + dirname(__FILE__) + "/getpage.js 'http://google.com'";
//echo shell_exec("/usr/local/bin/phantomjs " + dirname(__FILE__) + "/getpage.js 'http://google.com'");

?>