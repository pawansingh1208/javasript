'use strict';

describe('test channelSvc', function () {

    beforeEach(module('loyakk-services'));

    var channelSvc, appSvc;
    beforeEach(inject(function (_channelSvc_, _appSvc_) {
        channelSvc = _channelSvc_;
        appSvc = _appSvc_;

    }));

    it('test various channels', function () {
        waits(2000);
        channelSvc.getVariousChannels(38383, {type: 'featured', maxCount: 4}).then(function (channel) {
            expect(channel.length).toBe(4);
        }, function () {
            expect('FAILED').toBe("SUCCESS");
        });

        channelSvc.getVariousChannels(38383, {type: 'user', maxCount: 1}).then(function (channel) {
            expect(channel.length).toBe(1);
        }, function () {
            expect('FAILED').toBe("SUCCESS");
        });
    });

//    it('test ', function(){
//        waits(2000);
//        channelSvc.getTrendingChannels({currentvenueId:38383, type:'nearby', latitude:'37.38850000', longitude:'-122.07410000', trendHours: 24, radius:50}).then(function (channel) {
//            console.log(channel);
//            expect(channel.length).toBe(1);
//        }, function () {
//            expect('FAILED').toBe("SUCCESS");
//        });
//    });

    it('test channel name', function () {
        waits(2000);
        channelSvc.getChannelName(1099597).then(function (data) {
            console.log(data);
            expect(data).toBe('Sunnyvale HB Fans');
        }, function () {
            expect('FAILED').toBe("SUCCESS");
        });
    });


//    it('test add channel', function () {
//        var userId = '';
//        runs(function () {
//            appSvc.autoLogin().then(function (data) {
//                userId = data.userId;
//            });
//        });
//        waits(2000);
//        runs(function(){
//        channelSvc.addChannel({userId: userId,venueId: 38383, channelName: "play Cricket!", password: "abcdef",
//                              privateMessage: "Call to get password...", description: "Test description"}).then(function (channel) {
//            console.log(channel);
//           // expect(data).toBe('Sunnyvale HB Fans');
//        }, function () {
//            expect('FAILED').toBe("SUCCESS");
//        });
//        });
//        waits(5000);
//    });
//
//    it('test edit channel', function () {
//        var userId = '';
//        runs(function () {
//            appSvc.autoLogin().then(function (data) {
//                userId = data.userId;
//            });
//        });
//        waits(2000);
//        runs(function(){
//            channelSvc.editChannel(1100319, {userId: userId,venueId: 38383, channelName: "Lets talk about Cricket!",
//                                    password: "abcdef", privateMessage: "Call me to get password...",
//                                    description: "Test description", changePassword: true}).then(function (channel) {
//                console.log(channel);
//                // expect(data).toBe('Sunnyvale HB Fans');
//                channelSvc.getMyChannels(userId).then(function(channel){
//                   console.log(channel);
//                },function(){
//                    expect('FAILED TO GET MY CHANNEL').toBe("SUCCESS");
//                   });
//                    waits(5000);
//            }, function () {
//                expect('FAILED').toBe("SUCCESS");
//            });
//        });
//        waits(5000);
//    });

//    it('Delete a channel', function(){
//        var userId = '';
//        runs(function () {
//            appSvc.autoLogin().then(function (data) {
//                userId = data.userId;
//            });
//        });
//        waits(2000);
//        runs(function(){
//            channelSvc.deleteChannel(1100319, userId).then(function(channel){
//                console.log(channel);
//            },function(){
//                expect('FAILED').toBe("SUCCESS");
//            });
//           waits(5000);
//        });
//    });
});