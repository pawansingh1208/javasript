'use strict';

describe('appSvc', function () {
    beforeEach(module('loyakk-services'));

    var appSvc;
    beforeEach(inject(function (_appSvc_) {
        appSvc = _appSvc_;
    }));

    it('should do something', function () {
        expect(!!appSvc).toBe(true);
        expect(appSvc.baseUrl).toBe('http://api.loyakk.com/');
    });
    it('test auto login', function () {
        waits(2000);
        appSvc.autoLogin().then(function (data) {
            expect(data.authenToken.length).toBe(48);
        }, function() {
            expect('FAILED').toBe("SUCCESS");
        });
    });
});
