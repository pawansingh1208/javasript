'use strict';

describe('Service: myService', function () {
    // load the service's module
    beforeEach(module('loyakk-services'));
    var loggedIn = false;
    beforeEach(inject(function ( _appSvc_) {
        if(loggedIn) return;
        var appSvc = _appSvc_;
        appSvc.autoLogin();
        loggedIn =  true
    }));

    describe('appSvc', function () {
        // instantiate service
        var appSvc, rootScope;
        beforeEach(inject(function (_appSvc_, $rootScope) {
            appSvc = _appSvc_;
            rootScope = $rootScope;

        }));
        it('should do something', function () {
            expect(!!appSvc).toBe(true);
            expect(appSvc.baseUrl).toBe('http://api.loyakk.com/');
        });
      it('test auto login', function(){
          appSvc.autoLogin().then(function(data) {
              expect(data.authenToken).toBe();
          });
      }) ;

    });
    describe('test venueSvc', function () {
        // instantiate service
        var venueSvc, rootScope;
        beforeEach(inject(function (_venueSvc_, _appSvc_, $rootScope) {
            venueSvc = _venueSvc_;
            rootScope = $rootScope;
            var appSvc = _appSvc_;
            runs(function(){
                appSvc.autoLogin();
            });
            waits(2000);
        }));

        it('test popular venues', function () {
            runs(function () {
                venueSvc.getPopularVenues();
            });
            waits(2000);
            runs(function () {
                expect(rootScope.gData.popularVenues.length).toBe(6);
            });
        });

        it('test Favorite venues', function(){
           runs(function(){
               venueSvc.getFavoriteVenues();

           });
           waits(2000);
            runs(function(){
//               expect(rootScope.gData.favoriteVenues).toBe(6);
            });
        });
        it('test Recent venues', function(){
           runs(function(){
               venueSvc.getRecentVenues();

           });
           waits(2000);
            runs(function(){
//               expect(rootScope.gData.recentVenues.length).toBe(6);
            });
        });
    });
    describe('test channelSvc', function (){

        var channelSvc, rootScope;
        beforeEach(inject(function (_channelSvc_, $rootScope){
            channelSvc = _channelSvc_;
            rootScope = $rootScope;
        }));

        it('test various channels', function(){
            runs(function(){
                channelSvc.getVariousChannels();
            });
            waits(2000);
            runs(function () {

                expect(rootScope.gData.featuredChannels.length).toBe(4);
            });
        });

        it('test channel conversation', function(){
            runs(function(){
                channelSvc.getTrendingChannels();
            });
            waits(2000);
            runs(function () {
                expect(rootScope.gData.trendingChannels.length).toBe(0);
            });
        });
    });
    describe('test conversationSvc', function (){

        var converSvc, rootScope;
        beforeEach(inject(function (_conversationSvc_, $rootScope){
            converSvc = _conversationSvc_;
            rootScope = $rootScope;
        }));

        it('test popular conversation', function(){
            runs(function(){
                converSvc.getPopularConversations();
            });
            waits(2000);
            runs(function () {
                expect(rootScope.gData.popularConversations.length).toBe(6);
            });
        });

        it('test channel conversation', function(){
            runs(function(){
                converSvc.getChannelConversations();
            });
            waits(2000);
            runs(function () {
                expect(rootScope.gData.channelConversations.length).toBe(2);
            });
        });
    });

    describe('test messageSvc', function () {
        // instantiate service
        var msgSvc, rootScope, appSvc;
        beforeEach(inject(function (_messageSvc_, _appSvc_, $rootScope) {
            msgSvc = _messageSvc_;
            rootScope = $rootScope;
            appSvc = _appSvc_;

        }));

        it('test spam', function () {
            runs(function () {
                // Create a message
                msgSvc.spam();
            });
            waits(1000);
            runs(function () {
               //expect(rootScope.gData.messages.numSpams).toBe(true);
            });
        });
        it('test random conversation', function(){
            runs(function(){
             msgSvc.getRandomConversations();
           });
            waits(2000);
            runs(function(){
                expect(rootScope.gData.randomConversationMessages.length).toBe(1);
            });
        });
    });
});
