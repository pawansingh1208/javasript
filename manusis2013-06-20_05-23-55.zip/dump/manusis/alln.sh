node ../../r.js/r.js all-server.js
