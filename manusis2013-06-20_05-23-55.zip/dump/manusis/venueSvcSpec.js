'use strict';

describe('test venueSvc', function () {

    beforeEach(module('loyakk-services'));

    var venueSvc, appSvc;
    beforeEach(inject(function (_venueSvc_, _appSvc_) {
        venueSvc = _venueSvc_;
        appSvc = _appSvc_;

    }));


//     //failed
//    it('testing venues by userowned', function () {
//        runs(function () {
//            appSvc.autoLogin();
//        });
//        waits(2000);
//        runs(function () {
//            venueSvc.GetVenuesOwnedByUser(3448).then(function (venues) {
//                console.log(venues);
//                expect(venues.length).toBe(0);
//            }, function () {
//                expect('FAILED').toBe("SUCCESS");
//            });
//        });
//        waits(2000);
//    });
//
//    //failed
//    it('testing venues by venueid', function () {
//
//        waits(2000);
//        venueSvc.getVenueById(38383).then(function (venues) {
//            console.log(venues);
//            expect(venues).toBe('Okapo webapp sample');
//        }, function () {
//            expect('FAILED').toBe("SUCCESS");
//        });
//        waits(2000);
//    });
//
////      //failed
//    it('testing make favorite venues', function () {
//        var userId = '';
//        var nickName = '';
//        runs(function () {
//            appSvc.autoLogin().then(function (data) {
//                userId = data.userid;
//                nickName = data.nickname;
//            });
//        });
//        waits(2000);
//
//        runs(function () {
//            venueSvc.makeFavoriteVenue(3448, 338, {enabled: true}).then(function (data) {
//                expect(data).toBe(true);
//            }, function () {
//                expect('FAILED').toBe("SUCCESS");
//            });
//        });
//        waits(2000);
//    });
////       //failed
//    it('testing favorite venues', function () {
//        var userId = '';
//        var nickName = '';
//        runs(function () {
//            appSvc.autoLogin().then(function (data) {
//                userId = data.userid;
//                nickName = data.nickname;
//            });
//        });
//        waits(2000);
//        runs(function () {
//            venueSvc.makeFavoriteVenue(3448, 38, {userid: userId, nickname: nickName, enabled: true}).then(function (data) {
//                expect(data).toBe(true);
//            }, function (data) {
//                expect('FAILED').toBe("SUCCESS");
//            });
//        });
//        waits(2000);
//
//        runs(function () {
//            venueSvc.getFavoriteVenues(3448, {userid: userId, nickname: nickName}).then(function (venues) {
//                console.log(venues);
//                expect(venues.length).toBe(1);
//            }, function (data) {
//                expect('FAILED').toBe("SUCCESS");
//            });
//        });
//        waits(2000);
//    });

 /*
    it('testing delete favorite venues', function () {
        var userId = '';
        var nickName = '';
        runs(function () {
            appSvc.autoLogin().then(function (data) {
                userId = data.userid;
                nickName = data.nickname;
            });
        });
        waits(2000);
        runs(function () {
            venueSvc.deleteFavoriteVenue(3448, 38383, {userid: userId, nickname: nickName}).then(function (data) {
                expect(data).toBe(true);
            }, function () {
                expect('FAILED').toBe("SUCCESS");
            });
        });
        waits(2000);
    });

     // success
     it('testing get venues', function () {
         waits(2000);
         venueSvc.getVenues({latitude: 10, longitude: 15, radius: 10, maxCount: 6}).then(function (venues) {
             expect(venues.length).toBe(1);
         }, function () {
             expect('FAILED').toBe("SUCCESS");
         });
         waits(2000);
     });
     //    success
     it('testing popular venues', function () {
         waits(2000);
         venueSvc.getPopularVenues({maxCount: 6}).then(function (venues) {
             expect(venues.length).toBe(6);
         }, function () {
             expect('FAILED').toBe("SUCCESS");
         });
         waits(2000);
     });

     //success
     it('testing nearby venues', function () {
         waits(2000);
         venueSvc.getNearbyVenues({latitude: 37.45, longitude: -121.97, radius: 10, maxCount: 6}).then(function (venues) {
             expect(venues.length).toBe(6);
         }, function () {
             expect('FAILED').toBe("SUCCESS");
         });
         waits(2000);
     });
 */
     // success
     it('testing venues by name', function () {
         var venue = "man";
         waits(2000);
         venueSvc.getVenueByName(venue, {maxCount:6}).then(function (venues) {
             expect(venues.length).toBe(6);
         }, function () {
             expect('FAILED').toBe("SUCCESS");
         });
         waits(2000);
     });
 /*
     //success
     it('testing set current venues', function () {
     var userId = '';
     var nickName = '';
     runs(function () {
     appSvc.autoLogin().then(function (data) {
     userId = data.userid;
     nickName = data.nickname;
     });
     });
     waits(2000);
     runs(function () {
     venueSvc.setCurrentVenue(3448, 38383, {userid: userId, nickname: nickName}).then(function (data, status) {
     console.log(data);
     console.log(status);
     expect(data).toBe('');
     }, function () {
     expect('FAILED').toBe("SUCCESS");
     });
     });
     waits(2000);
     });

     //success
     it('testing recent venues', function () {
         var userId = '';
         var nickName = '';

         runs(function () {
             appSvc.autoLogin().then(function (data) {
                 userId = data.userid;
                 nickName = data.nickname;
             });
         });
         waits(2000);
         runs(function () {
             venueSvc.setCurrentVenue(3448, 38383, {userid: userId, nickname: nickName}).then(function (data) {
                 console.log(data);
                 expect(data).toBe('');
             }, function () {
                 expect('FAILED').toBe("SUCCESS");
             });
         });
         waits(2000);

         runs(function () {
             venueSvc.getRecentVenues(3448, {userid: userId, nickname: nickName}).then(function (venues) {
                 console.log(venues);
                 expect(venues.length).toBe(1);
             }, function (data) {
                 expect('FAILED').toBe("SUCCESS");
             });
         });
         waits(3000);
     });
   */

});