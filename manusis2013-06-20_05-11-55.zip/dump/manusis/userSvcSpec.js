'use strict';

describe('test userSvc', function () {

    beforeEach(module('loyakk-user-service'));

    var userSvc;
    beforeEach(inject(function (_userSvc_) {
        userSvc = _userSvc_;
    }));
    it('should do something', function () {
        expect(!!userSvc).toBe(true);
        expect(userSvc.baseUrl).toBe('http://api.loyakk.com/');
    });

    it('test user services', function () {
        var userName = "testuser_" + (new Date().getUTCMilliseconds());
        var emailId = userName + "@loyakk.com";
        var password = userName;
        // check if username is available. exepct to be true
        waits(2000);
        runs(function(){
            userSvc.isNickNameAvailable(userName).then(function(data){
                console.log(data);
                expect(data).toBe('');
            }, function() {
                expect('FAILED').toBe('SUCCESS');
            });
        });
        waits(2000);

        runs(function(){
            userSvc.registerNickName({
                    nickname: userName,
                    emailId: emailId,
                    password: password
                }).then(function (data) {
                expect(data.mediaList.superUser).toBe(undefined);
            }, function() {
                expect('FAILED').toBe("SUCCESS");
            });
        });

        // login
        waits(2000);
        runs(function(){
            userSvc.login({nickname: 'testuser_151', password: 'testuser_151'}).then(function(data){
                expect(data.mediaList.superUser).toBe(undefined);
            }, function() {
                expect('FAILED').toBe('SUCCESS');
            });
        });
        waits(2000);

//        //edit profile
//        runs(function(){
//            userSvc.editUserProfile({ userId: 11418, newNickname:"vijay123", firstName:"John", lastName:"Doe", authenToken:"dGVzdHVzZXJfMTUxOnRlc3R1c2VyXzE1MQ=="}).then(function(data){
//                console.log(data);
//            },function() {
//                expect('FAILED').toBe('SUCCESS');
//            });
//        });
//        waits(2000);
//        runs(function(){
//            userSvc.getUserInfo(11441).then(function(data){
//                console.log(data);
//            },function() {
//                expect('FAILED').toBe('SUCCESS');
//            });
//        });
//        waits(2000);
//        runs(function(){
//            userSvc.getEmailByNickname('testuser_151').then(function(data){
//                expect(data).toBe('');
//            }, function() {
//                expect('FAILED').toBe('SUCCESS');
//            });
//
//        });
//        waits(2000);
//        runs(function(){
//            userSvc.getPublicUserInfo(11418).then(function(data){
//                expect(data).toBe(1);
//            }, function() {
//                expect('FAILED').toBe('SUCCESS');
//            });
//        });
//        waits(2000);
//        runs(function(){
//            userSvc.forgotPassword({emailId: 'testuser_151@loyakk.com'}).then(function(data){
//                console.log(data);
//            },function() {
//                expect('FAILED').toBe('SUCCESS');
//            });
//        });
//        waits(2000);
//        runs(function(){
//            userSvc.resetPassword(resetToken).then(function(data){
//                console.log(data);
//            },function() {
//                expect('FAILED').toBe('SUCCESS');
//            });
//        });
//        waits(2000);
//        runs(function(){
//            userSvc.ChangePassword({ userId: 11418, oldPassword: oldPassword, newPassword:newPassword}).then(function(data){
//                console.log(data);
//            },function() {
//                expect('FAILED').toBe('SUCCESS');
//            });
//        });
//        waits(2000);
//

    });

});