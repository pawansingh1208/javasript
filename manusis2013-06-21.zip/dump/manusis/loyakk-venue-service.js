angular.module('loyakk-services').factory('venueSvc', function ($rootScope, appSvc, $http, $q) {

    var svc = {

        // getting popular venues
        getVenues: function (params) {
            var deferred = $q.defer();
            if (!params)params = {};
            var api_url = appSvc.baseUrl + 'venues';
            $http.get(api_url, {params: params}).success(function (data) {
                deferred.resolve(data.venues);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        //get nearby venues
        getNearbyVenues: function (params) {
            var deferred = $q.defer();
            if (!params)params = {};
            var api_url = appSvc.baseUrl + 'venues/nearby';
            $http.get(api_url, {params: params}).success(function (data) {
                deferred.resolve(data.venues);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        //get popular venues
        getPopularVenues: function (params) {
            var deferred = $q.defer();
            if (!params)params = {};
            var api_url = appSvc.baseUrl + 'venues/popular';
            $http.get(api_url, {params: params}).success(function (data) {
                deferred.resolve(data.venues);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        //make favorite venues
        makeFavoriteVenue: function (userId, venueId, params) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrlSecure + 'users/' + userId + '/favorite/venue/' + venueId;
            $http.put(api_url, params).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        // get favorite venues
        getFavoriteVenues: function (userId, params) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrlSecure + 'users/' + userId + '/favorite/venue';
            $http.get(api_url, {params: params}).success(function (data) {
                deferred.resolve(data.venues);
            }).error(function (data) {
//                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        //delete favorite vaenues
        deleteFavoriteVenue: function (userId, venueId, params) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrlSecure + 'users/' + userId + '/favorite/venue/' + venueId;
            $http.delete(api_url, {params: params}).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        //set current venue
        setCurrentVenue: function (userId, venueId, params) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrlSecure + 'users/' + userId + '/venue/' + venueId;
            $http.put(api_url, params).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
//                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        // get recent venues
        getRecentVenues: function (userId, params) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrlSecure + 'users/' + userId + '/recentvenues';
            $http.get(api_url, {params: params}).success(function (data) {
                deferred.resolve(data.venues);
            }).error(function (data) {
//                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        //get venue by name
        getVenueByName: function (venueKey, params) {
            if(svc.canceler){
                svc.canceler.resolve();
            }
            svc.canceler = $q.defer();
            var deferred = $q.defer();
            if (!params)params = {};
            var api_url = appSvc.baseUrl + 'venues/name/' + venueKey;
            $http({method: 'GET', url: api_url, params: params, timeout: svc.canceler.promise}).success(function (data) {
                deferred.resolve(data.venues);
            }).error(function (data) {
                    deferred.reject();
                });
            return deferred.promise;
        },

        //get venue by venueid
        getVenueById: function (venueId) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrl + 'venues/' + venueId + "/info";
            $http.get(api_url).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    deferred.reject();
                });
            return deferred.promise;
        },

        //get venue owned by user
        GetVenuesOwnedByUser: function (userId, params) {
            var deferred = $q.defer();
            if(!params)params={};
            var api_url = appSvc.baseUrlSecure + 'users/' + userId + '/venuesowned';
            $http.get(api_url, {params: params}).success(function (data) {
                deferred.resolve(data.venues);
            }).error(function (data) {
                    deferred.reject();
                });
            return deferred.promise;
        }

    };
    return svc;
});