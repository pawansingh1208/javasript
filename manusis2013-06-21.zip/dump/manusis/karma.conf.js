// Karma configuration

// base path, that will be used to resolve files and exclude
basePath = '../';

// list of files / patterns to load in the browser
files = [
    JASMINE,
    JASMINE_ADAPTER,
    'YeoTest/app/scripts/vendor/angular.min.js',
    'YeoTest/app/scripts/vendor/angular-mocks.js',
    'YeoTest/app/scripts/loyakk-app-service.js',
    'YeoTest/app/scripts/vendor/jquery.js',
    'YeoTest/app/scripts/loyakk-user-service.js',
    'YeoTest/app/scripts/loyakk-venue-service.js',
    'YeoTest/app/scripts/loyakk-channel-services.js',
 'YeoTest/app/scripts/loyakk-conversation-service.js',
    'YeoTest/app/scripts/loyakk-message-services.js',
   // 'YeoTest/app/scripts/loyakk-services.js',
  // 'YeoTest/app/test/unit/venueSvcSpec.js',
   // 'YeoTest/app/test/unit/userSvcSpec.js',
   // 'YeoTest/app/test/unit/appSvcSpec.js',
 // 'YeoTest/app/test/unit/channelSvcSpec.js',
 // 'YeoTest/app/test/unit/conversationSvcSpec.js',
'YeoTest/app/test/unit/messagesSvcSpec.js'
//    'test/unit/*.js'
];

// list of files to exclude
exclude = [];

// test results reporter to use
// possible values: dots || progress || growl
reporters = ['progress'];

// web server port
port = 8080;

// cli runner port
runnerPort = 9100;

// enable / disable colors in the output (reporters and logs)
colors = true;

// level of logging
// possible values: LOG_DISABLE || LOG_ERROR || LOG_WARN || LOG_INFO || LOG_DEBUG
logLevel = LOG_INFO;

// enable / disable watching file and executing tests whenever any file changes
autoWatch = true;

// Start these browsers, currently available:
// - Chrome
// - ChromeCanary
// - Firefox
// - Opera
// - Safari (only Mac)
// - PhantomJS
// - IE (only Windows)
browsers = ['Chrome'];

//browsers = ['ChromeCanary'];

// If browser does not capture in given timeout [ms], kill it
captureTimeout = 10000;

// Continuous Integration mode
// if true, it capture browsers, run tests and exit
singleRun = false;

