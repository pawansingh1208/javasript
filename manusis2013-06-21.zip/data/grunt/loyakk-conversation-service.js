angular.module('loyakk-services').factory('conversationSvc', function ($rootScope, appSvc, $http, $q) {

    var svc = {

        getPrivateConversations: function (userId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrlSecure + 'conversations/v2/user/' + userId + '/private';
            $http.get(api_url, { params: params}).success(function (data) {
                deferred.resolve(data.conversations);
            }).error(function (data) {

                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        getPublicConversations: function (userId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrl + 'conversations/user/' + userId + '/public';
            $http.get(api_url, { params: params}).success(function (data) {
                deferred.resolve(data.conversations);
            }).error(function (data) {

                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        getPopularConversations: function (params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrl + 'conversations/popularConversations';
            $http.get(api_url, { params: params}).success(function (data) {
                deferred.resolve(data.conversations);
            }).error(function (data) {

                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        getChannelConversations: function (channelId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrl + 'channels/' + channelId + '/conversations';
            $http.get(api_url, {params: params}).success(function (data) {
            	var output = {};
            	for(var i in data.conversations) {
            		var c = data.conversations[i];
            		output[c.conversationId] = c;
            	}
                deferred.resolve(output);
            }).error(function (data) {
                    deferred.reject();
                });
            return deferred.promise;
        },

        getNearbyConversations: function (params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrl + 'conversations/nearby';
            $http.get(api_url, { params: params}).success(function (data) {
                deferred.resolve(data.conversations);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        addNewConversation: function (channel_id, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrlSecure + 'channels/v3/' + channel_id;
            $http.post(api_url, params).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    deferred.reject();
                });
            return deferred.promise;
        },

        getRandomConversations: function (conversationId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrl + 'conversations/randomConversation';
            $http.get(api_url, {params: params}).success(function (data) {
                deferred.resolve(data.messages);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        getVenueConversations: function (venueId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrl + 'venues/' + venueId + '/conversations';
            $http.get(api_url, {params: params}).success(function (data) {
            	var output = {};
            	for(var i in data.conversations) {
            		var c = data.conversations[i];
            		output[c.conversationId] = c;
            	}
                deferred.resolve(output);
            }).error(function (data) {
                    deferred.reject();
                });
            return deferred.promise;
        },
        
        getConversationInfo: function (convId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrl + 'conversations/' + convId;
            $http.get(api_url, {params: params}).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    deferred.reject();
                });
            return deferred.promise;
        },
        getPrivateChannelConversation: function (userId, channelId, params) {
            var deffered = $q.defer();
            if(!params) params= {};
            var api_url = appSvc.baseUrlSecure + 'users/' + userId + '/channel/' + channelId + '/conversations';
            $http.get(api_url,{params:params}).success(function(data){
                deffered.resolve(data);
            }).error(function(data){
                deffered.reject();
            });
            return deffered.promise;
        }
        
    };
    return svc;

});