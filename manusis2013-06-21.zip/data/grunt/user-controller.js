
angular.module('loyakk-web-app').controller("SignupCtrl", function($scope, userSvc, $http, $rootScope) {
	$scope.submitted_signUp = false;

	$scope.signUp = function() {
		$scope.submitted_signUp = true;
		if ($scope.password_signup != $scope.password2) {
			$scope.pass_error = "These passwords don't match. Try again? ";
			return;
		}
        if (( typeof $scope.NickName_signup == 'undefined' || !$scope.NickName_signup) || ( typeof $scope.email_signup == 'undefined' || !$scope.email_signup) || ( typeof $scope.password_signup == 'undefined' || !$scope.password_signup) || ( typeof $scope.password2 == 'undefined' || !$scope.password2))
            return;
		userSvc.isNickNameAvailable($scope.NickName_signup).then(function(usrNickname) {

			if (usrNickname.errorCode == 2000) {
				$scope.msg1 = usrNickname.description;
				return;
			}
			if (!document.getElementById('checkbox2').checked) {
				alert('Please accept the terms and condition!');
				return;
			}
			userSvc.registerNickName({
				nickname : $scope.NickName_signup,
				emailId : $scope.email_signup,
				password : $scope.password_signup
			}).then(function(usrData) {
                localStorage.currentUser = angular.toJson(usrData);
				$rootScope.currentUser = usrData;
				$http.defaults.headers.common = {
					'Authorization' : 'Basic ' + $rootScope.currentUser.authenToken,
					'Content-Type' : 'application/json'
				};
	            window.location.reload();
			});
		});

	};
    $scope.cancel = function() {
        $('#sign-up-modal').foundation('reveal', 'close');
        $scope.pass_error = "";
        $scope.password_signup = "";
        $scope.password2    = "";
        $scope.email_signup = "";
        $scope.NickName_signup = "";
        $scope.submitted_signUp = false;
    };
    $scope.closeSignupModal = function(){
        $scope.pass_error = "";
        $scope.password_signup = "";
        $scope.password2    = "";
        $scope.email_signup = "";
        $scope.NickName_signup = "";
        $scope.submitted_signUp = false;
    };
});

angular.module('loyakk-web-app').controller("SigninCtrl", function($scope, userSvc, venueSvc, $http, $rootScope) {
	$scope.submitted_signIn = false;
	$rootScope.signIn = function(nickname, password) {
        if(!nickname){
            nickname = $scope.nickname;
            password = $scope.password;
        }


		$scope.submitted_signIn = true;

		if (( typeof nickname == 'undefined' || !nickname) || ( typeof password == 'undefined' || !password))
			return;

		userSvc.login({
			nickname : nickname,
			password : password
		}).then(function(loginData) {

			if (loginData.errorCode == 2000) {
				$scope.msg = "INVALID NICKNAME AND PASSWORD";
				return;
			}
			localStorage.currentUser = angular.toJson(loginData);
			$rootScope.currentUser = loginData;
			$http.defaults.headers.common = {
				'Authorization' : 'Basic ' + $rootScope.currentUser.authenToken,
				'Content-Type' : 'application/json'
			};
            window.location.reload();
			//  $rootScope.currentUser = localStorage.currentUser;
			if (loginData.userId) {
				$('#sign-in-modal').foundation('reveal', 'close');
				document.getElementById('sign_in_form').reset();
				if ($rootScope.lastElement) {
					$($rootScope.lastElement).trigger($rootScope.lastEvent);
				}
				$scope.nickname = "";
				$scope.password = "";
				$scope.msg = "";
				$scope.submitted_signIn = false;
                venueSvc.GetVenuesOwnedByUser(loginData.userId).then(function(data) {
                    var venues = [];
                    for(var i in data){
                        venues.push(data[i].venueId);
                    }
                    localStorage.userVenues = angular.toJson(venues);
                    $rootScope.userVenues = localStorage.userVenues;
                });
            }
        });
	};
    $scope.closeSigninModal = function(){
        $scope.nickname = "";
        $scope.password = "";
        $scope.msg = "";
        $scope.submitted_signIn = false;
    };

	//forgot password
	$scope.forgotPassword = function() {
		$('#forgot_password').foundation("reveal", 'open');
	};
	$scope.submitted_forgot = false;
	$scope.Forgot_Password = function() {
		$scope.submitted_forgot = true;
		if (!$scope.email_forgot)
			return;
		userSvc.forgotPassword({
			emailId : $scope.email_forgot
		}).then(function(data) {
			if (data.errorCode == 2000) {
				$scope.err_msg = data.description;
				return;
			}
			if (data == '') {
				$scope.email_forgot = "";
				$scope.err_msg = "";
				$('#forgot_password').foundation("reveal", 'close');
				$('#forgot-password-success-modal').trigger('reveal:open');
			}
		});
	};
	$scope.cancel = function() {
		$('#forgot_password').foundation("reveal", 'close');
        $scope.email_forgot = "";
        $scope.err_msg = "";
	};
    $scope.closeForgotPassword = function(){
        $scope.email_forgot = "";
        $scope.err_msg = "";
    }
});

//myloyakk section controller
angular.module('loyakk-web-app').controller("myLoyakkCtrl", function($scope, $rootScope, userSvc, $http) {

	//Logout
	$scope.logout = function() {
		localStorage.removeItem('currentUser');
        localStorage.removeItem('userVenues');
		$rootScope.currentUser = {};
		window.location.reload();
	};

	//edit profile modal
	$scope.editProfile = function() {
		$('#edit-profile-modal').foundation('reveal', 'open');
	};

	//change password
	$scope.change_password = function() {
		$('#change-password-modal').foundation('reveal', 'open');
	};
});

//user profile edit and change-password
angular.module('loyakk-web-app').controller("userSettingsCtrl", function($scope, $rootScope, userSvc, $http) {
	$scope.$watch('currentUser', function(newValue) {
		if (!$rootScope.currentUser.userId)
			return;
		//get user info for prefetching data in edit-profile form
		userSvc.getUserInfo($rootScope.currentUser.userId).then(function(usrInfo) {
			if (!$rootScope.currentUser.userId)
				return;
			$scope.NewNickName = usrInfo.nickname;
			$scope.NewEmail = usrInfo.emailId;

		});
		$scope.availableNickname = function() {
			userSvc.isNickNameAvailable($scope.NewNickName).then(function(NewUserNickname) {
				if (NewUserNickname.errorCode == 2000) {
					$scope.error_msg = NewUserNickname.description;
					return;
				} else {
					$('.success_msg').css('color', 'green');
					$scope.error_msg = "NickName Available.......";
				}
			});
		};
		//edit profile save changes functionality
		$scope.saveProfile = function() {
			var params = {
				userId : $rootScope.currentUser.userId,
				newNickname : $scope.NewNickName,
				newEmail : $scope.NewEmail
			};
            userSvc.isNickNameAvailable($scope.NewNickName).then(function(NewUserNickname) {
                if (NewUserNickname.errorCode == 2000) {
                    $scope.error_msg = NewUserNickname.description;
                    return;
                } else {
                    $('.success_msg').css('color', 'green');
                    $scope.error_msg = "NickName Available.......";
                }
            });
			userSvc.editUserProfile(params).then(function(usr_data) {
				$('#edit-profile-modal').foundation('reveal', 'close');
                $scope.error_msg ="";
				//                  $scope.firstName    = '';
				//                  $scope.lastName     = '';

			});
		};
		$scope.cancel = function() {
			$('#edit-profile-modal').foundation('reveal', 'close');
            $scope.error_msg ="";
		};
        $scope.resetFieldEditProfile = function(){
            $scope.error_msg ="";
        };
	});
	$scope.savePassword = function() {
		if ($scope.new_password != $scope.confirm_new_password) {
			$scope.pass_error_match = "These passwords don't match. Try again? ";
			return;
		}
		var params = {
			userId : $rootScope.currentUser.userId,
			oldPassword : $scope.oldPassword,
			newPassword : $scope.new_password
		};
		userSvc.ChangePassword(params).then(function(password_data) {
			if (password_data.errorCode == 2000) {
				$scope.error_msg_old = "Wrong old password";
				return;
			}
			$scope.oldPassword = "";
			$scope.new_password = "";
			$scope.confirm_new_password = "";
			$scope.pass_error_match = "";
			$scope.error_msg_old = "";
			$('#change-password-modal').foundation('reveal', 'close');
		});
	};
	$scope.cancel = function() {
        $scope.oldPassword = "";
        $scope.new_password = "";
        $scope.confirm_new_password = "";
        $scope.pass_error_match = "";
        $scope.error_msg_old = "";
		$('#change-password-modal').foundation('reveal', 'close');
	};
    $scope.resetFieldonClose = function(){
        $scope.oldPassword = "";
        $scope.new_password = "";
        $scope.confirm_new_password = "";
        $scope.pass_error_match = "";
        $scope.error_msg_old = "";
    };
});
