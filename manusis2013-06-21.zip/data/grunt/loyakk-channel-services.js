angular.module('loyakk-services').factory('channelSvc', function ($rootScope, appSvc, $http, $q) {

    var svc = {

        getVariousChannels: function (venueId,params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrl + 'venues/' + venueId;
            $http.get(api_url,{params:params}).success(function (data) {
                deferred.resolve(data.channel);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        getTrendingChannels: function (venueId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrl + 'channels/trending';
            $http.get(api_url, {params: params}).success(function (data) {
                deferred.resolve(data.channel);
            }).error(function (data) {
                    console.log('error data');
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        getChannelName: function (channelId) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrl + 'channels/getname/' + channelId;
            $http.get(api_url).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },
        getChannelInfo: function (channelId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrl + 'channels/' + channelId + '/info';
            $http.get(api_url, {params:params}).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    deferred.reject();
                });
            return deferred.promise;
        },

        setChannelPassword: function (userId, channelId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrlSecure + 'users/' + userId + '/channel/' + channelId + '/password';
            $http.put(api_url, {params: params}).success(function (data) {
                deferred.resolve(data.channel);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        verifyChannelPassword: function (channelId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrlSecure + 'channels/' + channelId + '/verifypassword';
            $http.put(api_url, {params: params}).success(function (data) {
                deferred.resolve(data.channel);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        addChannel: function (params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrlSecure + 'channels';
            $http.post(api_url, params).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        editChannel: function (channelId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrlSecure + 'channels/' + channelId;
            $http.put(api_url, {params: params}).success(function (data) {
                deferred.resolve(data.channel);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        deleteChannel: function (channelId, userId) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrlSecure + 'channels/' + channelId + '/user/' + userId;
            $http.delete(api_url).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        getTotalFollowChannelNewMessageCounts: function (userId) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrlSecure + 'users/' + userId + '/followchannelnewmessagecounts';
            $http.get(api_url).success(function (data) {
                deferred.resolve(data.channel);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        getMyChannels: function (userId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrlSecure + 'users/' + userId + '/mychannels';
            $http.get(api_url, {params: params}).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        addFollowChannel: function (userId, followChannelId) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrlSecure + 'users/' + userId + '/followchannel/' + followChannelId;
            $http.put(api_url).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        deleteFollowChannel: function (userId, followChannelId) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrlSecure + 'users/' + userId + '/followchannel/' + followChannelId;
            $http.delete(api_url).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        getChannelFollowStatus: function (userId, channelId) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrlSecure + 'users/' + userId + '/channel/' + channelId + '/channelFollowStatus/';
            $http.get(api_url).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        getFollowChannels: function (userId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrlSecure + 'users/' + userId + '/followchannels';
            $http.get(api_url, {params: params}).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },
        getChannelAccessStatus: function(userId, channelId, params){
            if(!userId) return;
            var deferred = $q.defer();
            if(!params) params = {};
            var api_url = appSvc.baseUrlSecure + 'users/' + userId + '/channel/' + channelId + '/channelAccessStatus';
            $http.get(api_url, {params:params}).success(function(data){
                deferred.resolve(data);
            }).error(function(data){
                    deferred.reject();
            });
            return deferred.promise;
        }

    };
    return svc;
});
