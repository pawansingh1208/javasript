angular.module('loyakk-services', []).factory('appSvc', function ($http, $rootScope, $q) {

    var supportCors = $.support.cors ;
    //var supportCors = false;
    var svc = {
        baseUrl: supportCors? 'http://api.loyakk.com/' : 'http://www.loyakk.com/webapp/api/',
        baseUrlSecure: supportCors ? 'https://api.loyakk.com/' : 'https://www.loyakk.com/webapp/api/',
        maxCount: 20,
        authorizationHeader: '',
        getQueryVariable: function (variable) {
            var query = window.location.search.substring(1);
            var vars = query.split('&');

            for (var i = 0; i < vars.length; i++) {
                var pair = vars[i].split('=');
                if (decodeURIComponent(pair[0]) == variable) {
                    return decodeURIComponent(pair[1]);
                }
            }
        },

        autoLogin: function (venueId, nickname) {
            var deferred = $q.defer();
            if (!venueId || !nickname) {
                venueId = svc.getQueryVariable('venueId');
                nickname = svc.getQueryVariable('nickname');
            }
            if (!venueId || !nickname) {
                //console.log("venueId and nickname need to be passed in URL. Using defaults..");
                venueId = '38383';
                nickname = 'johndoe@visa';
            }
            // get the nickname and venueId from the location
            $http.post(svc.baseUrl + 'nickname/autologinappwebview', {
                nickname: nickname,
                venueId: venueId

            }).success(function (data) {
                    $http.defaults.headers.common = {
                        'Authorization': 'Basic ' + data.authenToken,
                        'Content-Type': 'application/json'
                    };
                    svc.authorizationHeader = 'Basic ' + data.authenToken;
                    deferred.resolve(data);
                }).error(function (data) {
                    // TBD handle errors globally
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        uploadMedia: function (file, keyPrefix, params, callbacks) {
            var deferred = $q.defer();
            var form = new FormData();
            form.append("file", file, file.name);
            var obj = {
                keyPrefix: keyPrefix,
                thumbnailRequired: true
            }
            form.append("text", angular.toJson(obj));
            var xhr = new XMLHttpRequest;
            if (callbacks) {
                if (callbacks.onprogress) {
                    xhr.upload.onprogress = callbacks.onprogress;
                }
            }
            //xhr.setRequestHeader('Content-Type', "application/json");

            xhr.onload = function (data, status) {
                $rootScope.$apply(function(){
                    if(xhr.status == 200) {
                        deferred.resolve(angular.fromJson(xhr.responseText));
                    }
                    else {
                        console.log("inside onerror");
                        deferred.reject(xhr.status);
                    }
                });
            }
            xhr.onerror = function (e) {
                console.log("inside onerror");
                deferred.reject(e);
            }
            xhr.open("POST", svc.baseUrl + 'media/upload');
            xhr.setRequestHeader('Authorization', svc.authorizationHeader);
            xhr.send(form);
            return deferred.promise;
        },

        retrieveMedia: function (keyname) {
            var deferred = $q.defer();
            var api_url = svc.baseUrl + 'media/download?keyname=' + keyname;
            $http.get(api_url).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        retrieveUserMedia: function (userId) {
            var deferred = $q.defer();
            var api_url = svc.baseUrl + 'media/userprof/download?id=' + userId;
            $http.get(api_url).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        updateMessageMedia: function (messageId, params) {
            if (!params)params = {};
            var deferred = $q.defer();
            var api_url = svc.baseUrl + 'messages/' + messageId + '/media';
            $http.put(api_url, params).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },

        updateChannelMedia: function (channelId, params) {
            if (!params)params = {};
            var deferred = $q.defer();
            var api_url = svc.baseUrl + 'channels/' + channelId + '/media';
            $http.put(api_url, params).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        }
    };
    return svc;
});
