angular.module('loyakk-web-app').run(function ($httpBackend) {
    venuesOwned =
        {"venues": [
            {"name": "Okapo webapp sample",
                "venueId": 38383,
                "numMessages": 0,
                "numLikes": 0,
                "passwordProtected": false,
                "hideNearby": false,
                "mediaList": [
                    {
                        "type": "jpg",
                        "keyname": "venue_1",
                        "category": "full"
                    },
                    {
                        "type": "gif",
                        "keyname": "venue124/diamond.gif",
                        "category": "thumbnail"
                    }
                ],
                "longName": "Okapo webapp sample"}
        ]};

    $httpBackend.whenGET(/\/venuesowned/).respond(venuesOwned);
    $httpBackend.whenGET(/.*/).passThrough();
    $httpBackend.whenDELETE(/.*/).passThrough();
    $httpBackend.whenPOST(/.*/).passThrough();
    $httpBackend.whenPUT(/.*/).passThrough();
});