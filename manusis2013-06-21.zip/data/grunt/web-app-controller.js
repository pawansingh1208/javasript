/**
 * @author manusis
 */
var m = angular.module('loyakk-web-app', ['loyakk-services', 'loyakk-filters']);
m.config(function ($routeProvider, $httpProvider, $locationProvider) {
    //$locationProvider.html5Mode(true);
    $routeProvider.when('/:venueid/:channelid/:convid', {
        templateUrl: 'main.html'
    }).when('/:venueid/:channelid', {
            templateUrl: 'main.html'
        }).when('/:venueid', {
            templateUrl: 'main.html'
        }).otherwise({redirectTo: '/159490'});
});

m.directive('userBind', function ($rootScope) {
    return function (scope, element, attrs) {
        element.bind('click', function () {
            if (!$rootScope.currentUser.userId) {
                // show popup
                $('#sign-in-modal').foundation('reveal', 'open');
                return false;

            }
        });
    };
});

m.run(function ($rootScope, venueSvc, channelSvc) {

    $rootScope.currentVenue = {};
    $rootScope.currentChannel = null;
    // Watch venueId, channelId and currentUser
    $rootScope.$watch("venueId", function (newValue, oldValue) {
        if (!newValue) return;
        $(".reveal-modal").foundation('reveal', 'close');
        $(".reveal-modal-bg").hide();

        // Venue id should always be there.
        venueSvc.getVenueById($rootScope.venueId).then(function (venue) {
            $rootScope.currentVenue = venue;

            var venueImage = null;
            for (var i in venue.mediaList) {
                var media = venue.mediaList[i];
                if (media.category.trim() == "webapp-splash") {
                    venueImage = media.keyname;
                    break;
                }
            }
            if (!venueImage) {
                for (var i in venue.mediaList) {
                    var media = venue.mediaList[i];
                    if (media.category.trim() == "welcome-screen-splash") {
                        venueImage = media.keyname;
                        break;
                    } else if (media.category.trim() == "welcome-screen") {
                        venueImage = media.keyname;
                        break;
                    } else {
                        media.category.trim() == "venue-banner-v2-bg";
                        venueImage = media.keyname;
                        break;
                    }
                }
            }
            if (venueImage) {
                $rootScope.venueStyle = {"background-image": "url('http://loyakk-ctnt-public.s3.amazonaws.com/" + venueImage + "')"};

            }
            $rootScope.$broadcast("venueChanged");
        });
        $rootScope.$broadcast("venueIdChanged");
    });
    $rootScope.$watch("channelId", function (newValue, oldValue) {
        if (!newValue) {
            $rootScope.currentChannel = null;
            $rootScope.$broadcast("channelChanged");
            return;
        }
        $(".reveal-modal").foundation('reveal', 'close');
        $(".reveal-modal-bg").hide();

        // Get current channel info
        var params = {};
        if ($rootScope.currentUser.userId) {
            params.reqUserId = $rootScope.currentUser.userId;
        }
        channelSvc.getChannelInfo($rootScope.channelId, params).then(function (channel) {
            $rootScope.currentChannel = channel;
            $rootScope.$broadcast("channelChanged");
        });
    });
    $rootScope.$watch("currentUser", function (newValue, oldValue) {
        if (!newValue || !newValue.userId) return;
        $rootScope.$broadcast("userChanged");
    });
});


m.controller('WebAppCtrl', function ($rootScope, $location, $scope, $route, $location, $http, appSvc, venueSvc, userSvc, conversationSvc, channelSvc, messageSvc, $routeParams) {

    $rootScope.venueId = $routeParams.venueid;
    $rootScope.channelId = $routeParams.channelid;
    $rootScope.conversationId = $routeParams.convid;
    $rootScope.currentUser = {};
    $scope.$on("userChanged", function () {
        $http.defaults.headers.common = {
            'Authorization': 'Basic ' + $rootScope.currentUser.authenToken,
            'Content-Type': 'application/json'
        };
        followChannel($rootScope.currentUser);
        favoriteVenue($rootScope.currentUser);
        recentVenues($rootScope.currentUser);
        if ($rootScope.currentUser.userId && $rootScope.venueId) {
            venueSvc.setCurrentVenue($rootScope.currentUser.userId, $rootScope.venueId);
        }
    });

    $scope.$on("channelChanged", function () {
        updateChannelFollowStatus();
        var currentChannel = $rootScope.currentChannel;
        if (currentChannel.userChannel == true) {
            $scope.share_text = "Just created a new " + currentChannel.name + " channel at " + $rootScope.currentVenue.name + " on @LoYakk. Join the discussion.";
        } else {
            $scope.share_text = "The " + currentChannel.name + " channel at " + $rootScope.currentVenue.name + " on LoYakk is quite interesting. Join me in the discussion. You can get LoYakk from the Apple AppStore or Google Play at https://www.loyakk.com/go ";
        }
        if (currentChannel && currentChannel.url) {
            if (currentChannel.donateChannel == true) {
                if ($rootScope.currentUser.userId) {
                    $scope.url = currentChannel.url.replace("##userId##", $rootScope.currentUser.userId);
                } else {
                    $scope.errorMessage = "Please login first to see This Channel detail.";
                }
            } else {
                $scope.url = currentChannel.url;
            }

        }
        else {
            $scope.url = "";
        }
    });


    //showing alert box;
    $rootScope.showMessage = function (msg) {
        $rootScope.alertMsg = msg;
        $('#channelCreated').foundation("reveal", 'open');
        setTimeout(function () {
            $('#channelCreated').foundation("reveal", 'close');
        }, 2500);
    }

    //get favorite channels
    var followChannel = function () {
        if (!$rootScope.currentUser.userId) return;
        channelSvc.getFollowChannels($rootScope.currentUser.userId, {
        }).then(function (data) {
                $scope.favChannels = data.channel;
                return false;
            });
    };


    //get favorite venues
    var favoriteVenue = function (currentUser) {
        venueSvc.getFavoriteVenues($rootScope.currentUser.userId).then(function (venues) {
            $scope.favVenues = venues;
            for (var i = 0; i < $scope.favVenues.length; i++) {
                if ($scope.favVenues[i].venueId == $rootScope.venueId) {
                    $scope.isFavVenue = 1;
                    return;
                }
            }
        });
    };

    //get recent venues
    var recentVenues = function (currentUser) {
        venueSvc.getRecentVenues($rootScope.currentUser.userId).then(function (venues) {
            $scope.recentVenues = venues;
        });
    };

    // access current user from local storage
    if (localStorage.currentUser) {
        $rootScope.currentUser = angular.fromJson(localStorage.currentUser);
        $rootScope.userVenues = angular.fromJson(localStorage.userVenues);
//        $rootScope.handleUserChange();
    }


    $rootScope.updateAddthis = function () {
        setTimeout(function () {
            if (addthis) {
                addthis.init();
                addthis.toolbox(".addthis_toolbox");
                addthis.button(".share_button");
            }
        }, 200);

    }

    $rootScope.updateAddthis();

    var updateChannelFollowStatus = function () {
        if (!$rootScope.currentUser.userId) return;
        if (!$rootScope.channelId) return;
        channelSvc.getChannelFollowStatus($rootScope.currentUser.userId, $rootScope.channelId).then(function (data) {
            $scope.isFollowChannel = data.follow;
        });
    }

    $scope.favChannel = function (currentChannel) {
        if (!$rootScope.currentUser.userId)
            return;
        $scope.starLoader = 1;
        channelSvc.addFollowChannel($rootScope.currentUser.userId, currentChannel.channelId).then(function (data) {
            $scope.isFollowChannel = true;
            updateChannelFollowStatus(currentChannel);
            followChannel($rootScope.currentUser);
            $scope.starLoader = 0;
            $rootScope.showMessage(currentChannel.name + " channel has been subscribed.");
        }, function () {
            $scope.starLoader = 0;
            $rootScope.showMessage("Oops! Something went wrong subscribing a channel.");
        });
    };
    $scope.makeFavVenue = function (currentVenue) {
        if (!$rootScope.currentUser.userId)
            return;
        $scope.heartLoader = 1;
        venueSvc.makeFavoriteVenue($rootScope.currentUser.userId, currentVenue.venueId, {
            "enabled": "true"
        }).then(function (data) {
                favoriteVenue($rootScope.currentUser);
                $scope.isFavVenue = 1;
                $scope.heartLoader = 0;
                $rootScope.showMessage(currentVenue.name + " Venue has been favorite.");
            }, function () {
                $scope.heartLoader = 0;
                $rootScope.showMessage(" Oops! Something went wrong favoriting a venue.");
            });
    };
    $scope.deleteFavChannel = function (currentChannel) {
        if (!$rootScope.currentUser.userId)
            return;
        $scope.starLoader = 1;
        channelSvc.deleteFollowChannel($rootScope.currentUser.userId, currentChannel.channelId).then(function (data) {
            $scope.isFollowChannel = false;
            updateChannelFollowStatus(currentChannel);
            followChannel($rootScope.currentUser);
            $scope.starLoader = 0;
            $rootScope.showMessage(currentChannel.name + " channel has been un-subscribed.");
        }, function () {
            $scope.starLoader = 0;
            $rootScope.showMessage("Oops! Something went wrong in un-subscribing.");
        });
    };

    $scope.deleteFavVenue = function (currentVenue) {
        if (!$rootScope.currentUser.userId)
            return;
        $scope.heartLoader = 1;
        venueSvc.deleteFavoriteVenue($rootScope.currentUser.userId, currentVenue.venueId).then(function (data) {
            $scope.isFavVenue = 0;
            favoriteVenue($rootScope.currentUser);
            $scope.heartLoader = 0;
            $rootScope.showMessage(currentVenue.name + " Venue is un-favorited. ");
        }, function () {
            $scope.heartLoader = 0;
            $rootScope.showMessage(" Oops! Something went wrong while un-favoriting.");
        });
    };

    $scope.seeMore = function (heading, channels) {
        $rootScope.seemore = {heading: heading, channels: channels};
        $('#seemore-channels').foundation('reveal', 'open');

    };

    // when user selects channel either from venue channels or from subscribed channels links
    $scope.selectChannel = function (channelId) {
        $location.path("/" + $rootScope.venueId + "/" + channelId);

    };

    $scope.selectAllChannels = function () {
        $location.path("/" + $rootScope.venueId);
        $rootScope.currentChannel = null;
        $rootScope.channelId = null;
    };

    $scope.linkTo = function (venueId, channelId, conversationId) {
        var path = "/" + venueId;
        if (channelId) path += "/" + channelId;
        if (conversationId) path += "/" + conversationId;
        $location.path(path);
    }
});

m.controller('otherVenueListCtrl', function ($rootScope, $scope, venueSvc, conversationSvc) {
    $scope.$on('venueChanged', function () {
        if (!$rootScope.currentVenue.latitude)
            return;
        //get nearby venues
        venueSvc.getNearbyVenues({
            latitude: $rootScope.currentVenue.latitude,
            longitude: $rootScope.currentVenue.longitude,
            radius: 10
        }).then(function (data) {
                $rootScope.nearbyVenues = data;
            });
    });
    //getting popular venues
    if (!$rootScope.popularVenues) {
        $rootScope.popularVenues = venueSvc.getPopularVenues();
    }

    if (!$rootScope.popularConversations) {
        //getting popular conversations
        conversationSvc.getPopularConversations({
            maxCount: 4
        }).then(function (data) {
                $rootScope.popularConversations = data;
            });
    }

    //search venues by keyword/name
    $scope.venueKey = '';
    $scope.$watch('venueKey', function (newValue) {
        if (!$scope.venueKey) {
            $scope.searchVenues = "";
            $scope.loaderVenue = 0;
            return;
        }
        $scope.loaderVenue = 1;
        venueSvc.getVenueByName($scope.venueKey, {
//            latitude: $rootScope.currentVenue.latitude,
//            longitude: $rootScope.currentVenue.longitude,
            skipCount: 1
        }).then(function (data) {
                $scope.searchVenues = data;
                $scope.loaderVenue = 0;

            });
    });

    $scope.seeMore = function (heading, venues) {
        $rootScope.seemore = {heading: heading, venues: venues};
        $('#seemore-venues').foundation('reveal', 'open');
    };
});

m.controller("createChannelCtrl", function ($scope, $rootScope, userSvc, $http, appSvc, channelSvc) {
    $scope.setFile = function (file) {
        $scope.file = file;
        $scope.$apply();
        var reader = new FileReader();
        reader.onload = function (e) {
            $('.photo-thumb').css("background-image", "url(" + e.target.result + ")");
            $('.photo-thumb').css("background-size", "100% auto");
        }
        reader.readAsDataURL(file);
    };

    $scope.unsetFile = function () {
        $scope.file = 0;
        $('.photo-thumb').css("background-image", "url(../img/temp/venue.png)");
        $('.photo-thumb').css("background-size", "");
    };
    $scope.channelSubmit = false;
    $scope.addChannel = function () {
        $scope.channelSubmit = true;
        if (!$scope.channelName)
            return;
        /*if (!$scope.channelDescription)
         return;*/
        $('#add-channel-modal').foundation("reveal", 'close');
        $('#loadingModel').foundation("reveal", 'open');
        channelSvc.addChannel({
            userId: $rootScope.currentUser.userId,
            venueId: $rootScope.currentVenue.venueId,
            channelName: $scope.channelName,
            description: $scope.channelDescription
        }).then(function (channel) {
                var channelId = channel.channelId;
                if ($scope.file) {
                    appSvc.uploadMedia($scope.file, $scope.venueId + "/" + channelId).then(function (data) {
                        $scope.file = 0;
                        appSvc.updateChannelMedia(channelId, {
                            keyname: data.mediaKey,
                            category: "channel-v2-bg",
                            type: $scope.file.type
                        }).then(function (data) {
                                $scope.unsetFile();
                                $rootScope.loadChannels();
                                $('#loadingModel').foundation('reveal', 'close');
                                $rootScope.showMessage("Thank You. Your Channel has been Created.");
                            });
                    });
                } else {
                    $('#addChannelMessage').foundation('reveal', 'open');
                    $rootScope.loadChannels();
                    $('#loadingModel').foundation('reveal', 'close');
                    $rootScope.showMessage("Thank You. Your Channel has been Created.");
                }
                document.getElementById('add-channel').reset();
                $scope.channelSubmit = false;
                $scope.channelName = '';
                $scope.channelDescription = '';

            }, function () {
                $scope.unsetFile();
                document.getElementById('add-channel').reset();
                $scope.channelSubmit = false;
                $scope.channelName = '';
                $scope.channelDescription = '';
                $('#loadingModel').foundation('reveal', 'close');
                $rootScope.showMessage("Oops! Something went wrong while adding a new channel");
            });
    };
    $scope.cancel = function () {
        $scope.unsetFile();
        document.getElementById('add-channel').reset();
        $scope.channelSubmit = false;
        $scope.channelName = '';
        $scope.channelDescription = '';
        $('#sign-up-modal').foundation('reveal', 'close');
    };
    $scope.closeAddChannel = function () {
        $scope.unsetFile();
        document.getElementById('add-channel').reset();
        $scope.channelSubmit = false;
        $scope.channelName = '';
        $scope.channelDescription = '';
    };
});

m.controller("VenueChannels", function ($scope, $rootScope, conversationSvc, channelSvc, $location, appSvc) {

    $rootScope.loadChannels = function (channelId) {
        if (!channelId) {
            channelId = $rootScope.channelId;
        }
        var params = {};
        if ($rootScope.currentUser.userId) {
            params.reqUserId = $rootScope.currentUser.userId;
        }

        channelSvc.getVariousChannels($scope.venueId, params).then(function (data) {

            $rootScope.channels = data;

            if ($rootScope.channels.length <= 5) {
                $("#moreChannel").addClass('moreChannelOpaque');
            } else {
                $("#moreChannel").removeClass('moreChannelOpaque');
            }
            if ($rootScope.channelId) {
                for (var i = 0; i < $rootScope.channels.length; i++) {
                    if ($rootScope.channels[i].channelId == $rootScope.channelId) {
                        $rootScope.currentChannel = $rootScope.channels[i];
                    }
                }
                var index = $rootScope.channels.indexOf($rootScope.currentChannel);
                $rootScope.channels.splice(index, 1);
                $rootScope.channels.splice(0, 0, $rootScope.currentChannel);
            }
        });
    }

    $scope.morechannels = false;
    $scope.toggleChannel = function () {
        if ($rootScope.channels.length <= 5) {
            $scope.morechannels = false;
        } else {
            $scope.morechannels = true;
        }
    };
    $scope.toggleLessChannel = function () {
        $scope.morechannels = false;
    };

    $scope.$on("venueIdChanged", function () {
        $rootScope.loadChannels();
    });
    $scope.$on("channelChanged", function () {
        $rootScope.loadChannels();
    });
    $scope.setSelectedChannel = function (channel) {
        $rootScope.channelId = channel.channelId;
        $rootScope.currentChannel = channel;
        $rootScope.loadChannels();
    }

});

m.controller("ChannelConversations", function ($scope, $rootScope, appSvc, conversationSvc, channelSvc, messageSvc, $routeParams) {

    $scope.newPost = function () {
        if (!$scope.newConversation && !$scope.file) {
            $rootScope.showMessage('You can not post a blank conversation.');
            return;
        }
        if (!$scope.newConversation) {
            $scope.newConversation = ' ';
        }
        if (!$scope.currentUser.userId)
            return;
        if (!$rootScope.currentChannel) {
            $rootScope.showMessage("Select the channel from Channels list before posting.");
            return;
        }
        $scope.postloader = 1;

        var description = $scope.newConversation;
        var channel = $rootScope.currentChannel;
        conversationSvc.addNewConversation(channel.channelId, {
            userid: $scope.currentUser.userId,
            nickname: $scope.currentUser.nickname,
            message: $scope.newConversation
        }).then(function (data) {
                var conversationId = data.conversationId;
                var messageId = data.messageId;
                if ($scope.file) {
                    appSvc.uploadMedia($scope.file, $scope.venueId + "/" + channel.channelId + "/" + conversationId).then(function (data) {
                        appSvc.updateMessageMedia(messageId, {
                            keyname: data.mediaKey,
                            category: "message",
                            type: $scope.file.type
                        }).then(function (data) {
                                conversationSvc.getConversationInfo(conversationId).then(function (data) {
                                    data.description = description;
                                    $scope.conversations[data.conversationId] = data;
                                });
                                $scope.file = 0;
                                $scope.newConversation = '';
                                $scope.noConversations = false;
                                $scope.postloader = 0;
                            });
                    }, function () {
                        $scope.postloader = 0;
                        $scope.noConversations = false;
                        // $rootScope.showMessage("Oops! Something went wrong while uploading the image/file");
                    }, function () {
                        $scope.postloader = 0;
                        $rootScope.showMessage("Oops! Something went wrong while uploading the image/file.");
                    });
                } else {
                    conversationSvc.getConversationInfo(data.conversationId).then(function (data) {
                        data.description = description;
                        $scope.conversations[data.conversationId] = data;
                    });
                    // loadConversations();
                    $scope.newConversation = '';
                    $scope.postloader = 0;
                    $scope.noConversations = false;
                }
            }, function () {
                $scope.postloader = 0;
                $rootScope.showMessage("Oops! Something went wrong while posting your comment.");
            });
    };

    $rootScope.getMessages = function (conversation, type) {
        if (!conversation)
            return;
        $scope.loaderMessage = 1;
        if (type) {
            var maxCount = 20;
        } else {
            var maxCount = 3;
        }
        if ($rootScope.channelAccessStatus ? $rootScope.channelAccessStatus.status == 2 : false) {
            messageSvc.getPrivateChannelConvMessages($rootScope.currentUser.userId, conversation.conversationId).then(function (data) {
                for (var i in data.messages) {
                    if (data.messages[i].messageId == conversation.startMessageId) {
                        conversation.description = data.messages[i].description;
                    }
                    if (data.messages[i]) {
                        if ($rootScope.currentUser.userId == data.messages[i].userId) {
                            if (conversation.startMessageId == data.messages[i].messageId) {
                                data.messages[i].canDelete = false;
                            } else {
                                data.messages[i].canDelete = true;
                            }

                        } else {
                            data.messages[i].canDelete = false;
                        }
                        //console.log(data.messages[i].canDelete);
                    }
                }
                conversation.messages = data.messages;
                $scope.loaderMessage = 0;
                $rootScope.updateAddthis();

            }, function (data) {
                $scope.loaderMessage = 0;
            });
        } else {
            messageSvc.getMessages(conversation.conversationId, {
                maxCount: maxCount
            }).then(function (data) {
                    for (var i in data.messages) {
                        if (data.messages[i].messageId == conversation.startMessageId) {
                            conversation.description = data.messages[i].description;
                        }
                        if (data.messages[i]) {
                            if ($rootScope.currentUser.userId == data.messages[i].userId) {
                                if (conversation.startMessageId == data.messages[i].messageId) {
                                    data.messages[i].canDelete = false;
                                } else {
                                    data.messages[i].canDelete = true;
                                }

                            } else {
                                data.messages[i].canDelete = false;
                            }
                            //console.log(data.messages[i].canDelete);
                        }
                    }
                    conversation.messages = data.messages;
                    $scope.loaderMessage = 0;
                    $rootScope.updateAddthis();

                }, function (data) {
                    $scope.loaderMessage = 0;
                });
        }
        ;
    }

    $scope.setFile = function (file) {
        $scope.file = file;
        $scope.$apply();
        var reader = new FileReader();
        reader.onload = function (e) {
            //compressAndShowImage(e.target.result, file, $scope);
            //compressAndShowImage1(e.target.result, file, $scope);

            $(".img_file").append("img").prop("src", e.target.result);
        }
        reader.readAsDataURL(file);

    };
    $scope.unsetFile = function () {
        $scope.file = 0;
    };

    $scope.showComment = false;

    function showConversations(conversations) {
        if (Object.keys(conversations).length == 0) {
            $scope.noConversations = true;
        }
        if (Object.keys(conversations).length
            < 20) {
            $scope.noOlderConversations = true;
        }
        $scope.conversations = conversations;
        $rootScope.updateAddthis();
    }

    var loadConversations = function () {
        $scope.loader = 1;
        $scope.lastTimestamp = '';
        if ($rootScope.conversationId) return;
        if ($rootScope.channelId) {
            conversationSvc.getChannelConversations($rootScope.channelId).then(function (conversations) {
                showConversations(conversations);
                $scope.loader = 0
            }, function () {
                $scope.loader = 0;
            });
        } else {
            conversationSvc.getVenueConversations($scope.venueId).then(function (conversations) {
                showConversations(conversations);
                $scope.loader = 0;

            }, function () {
                $scope.loader = 0;
            });
        }
    };


    $scope.loadOlderConversations = function () {
        if ($scope.loadingConversations || $scope.loader || $scope.noOlderConversations || $scope.errorMessage) return;
        // get last conversation
        var timestamp = '';
        for (var i in $scope.conversations) {
            var conversation = $scope.conversations[i];
            if (!timestamp) {
                timestamp = conversation.timestamp;
            }
            if (timestamp > conversation.timestamp) {
                timestamp = conversation.timestamp;
            }
        }
        $scope.loadingConversations = true;
        if ($rootScope.channelId) {
            conversationSvc.getChannelConversations($rootScope.channelId, {newOld: 'old', timestamp: timestamp, maxCount: 20}).then(function (conversations) {
                if (Object.keys(conversations).length < 20) {
                    $scope.noOlderConversations = true;
                }
                for (var i in conversations) {
                    $scope.conversations[i] = conversations[i];
                }
                $scope.loadingConversations = false;
            }, function () {
                $scope.loadingConversations = false;

            });
        }
        else {
            conversationSvc.getVenueConversations($rootScope.venueId, {newOld: 'old', timestamp: timestamp, maxCount: 20}).then(function (conversations) {
                if (Object.keys(conversations).length < 20) {
                    $scope.noOlderConversations = true;
                }
                for (var i in conversations) {
                    $scope.conversations[i] = conversations[i];
                }
                $scope.loadingConversations = false;
            }, function () {
                $scope.loadingConversations = false;

            });
        }
    }
    $scope.$on("venueChanged", function () {
        var currentVenue = $rootScope.currentVenue;
        $scope.errorMessage = "";
        if (currentVenue && currentVenue.passwordProtected == true) {
            $scope.errorMessage = "This is password protected venue, you do not have access to it. Please visit this venue via the LoYakk Mobile App and initiate a request to the owner to grant you access.";
            return;
        }

    });

    $scope.$on("channelChanged", function () {
//        if (newValue && newValue.url) return;
        var currentChannel = $rootScope.currentChannel;
        $scope.errorMessage = '';
        if (currentChannel && currentChannel.privateChannel == true) {
            if ($rootScope.currentUser.userId) {
                channelSvc.getChannelAccessStatus($rootScope.currentUser.userId, $rootScope.currentChannel.channelId).then(function (data) {
                    $rootScope.channelAccessStatus = data;
                    if ($rootScope.channelAccessStatus.status == 2) {
                        conversationSvc.getPrivateChannelConversation($rootScope.currentUser.userId, $rootScope.channelAccessStatus.channelId).then(function (data) {

                            $rootScope.conversations = data.conversations;

                        });
                    } else {
                        $scope.errorMessage = "This is a private channel and currently, you do not have access to it. Please visit this channel via the LoYakk Mobile App and initiate a request to the owner to grant you access.";
                        return;
                    }
                });
            } else {
                $scope.errorMessage = "This is a private channel and currently, you do not have access to it. Please visit this channel via the LoYakk Mobile App and initiate a request to the owner to grant you access.";
                return;
            }
        }
        if (currentChannel && (currentChannel.passwordProtectedVenue == true || currentChannel.passwordProtected == true)) {
            $scope.errorMessage = "This is password protected venue, you do not have access to it. Please visit this channel via the LoYakk Mobile App and initiate a request to the owner to grant you access.";
            return;
        }
        loadConversations();
    });
    if (!$rootScope.conversationid) {
        loadConversations();
    }

});
m.controller("ConversationDetailCtrl", function ($scope, appSvc, messageSvc, $rootScope, conversationSvc) {
    //if (typeof($rootScope.conversationId) == "undefined")return;
    if (!$rootScope.conversationId) return;
    $scope.loader = 1;
    conversationSvc.getConversationInfo($rootScope.conversationId).then(function (conversation) {
        $scope.conversation = conversation;
        $rootScope.getMessages(conversation, 'detailConversation');
        $rootScope.updateAddthis();
        $scope.showComment = 1;
        $scope.loader = 0;
    });
});

m.controller("ConversationCtrl", function ($scope, appSvc, messageSvc, $rootScope) {

    $scope.delete_message = function (msg_id, type) {
        if (type) {
            messageSvc.deleteMessage($rootScope.currentUser.userId, msg_id).then(function (data) {

                $scope.conversation.numMessages -= 1;
                $rootScope.getMessages($scope.conversation);
            });
        } else {
            if ($scope.conversation.numMessages > 0) {
                $scope.showMessage("Sorry, You can't delete this conversation. Please delete all comments first.");

            } else {
                messageSvc.deleteMessage($rootScope.currentUser.userId, msg_id).then(function (data) {
                    delete $scope.conversations[$scope.conversation.conversationId];
                });
            }
        }

    }

    $scope.likeConversation = function (conversation) {
        if (!$rootScope.currentUser.userId) {
            return;
        }
        messageSvc.like(conversation.startMessageId, $rootScope.currentUser.userId).then(function (data) {
            conversation.numLikes += 1;
        });
    };

    $scope.likeMsg = function (message, conversation) {
        if (!$rootScope.currentUser.userId) {
            return;
        }
        messageSvc.like(message.messageId, $rootScope.currentUser.userId).then(function (data) {
            message.numLikes += 1;
            conversation.numLikes += 1;
        });
    };

    $scope.spamConversation = function (conversation) {
        if (!$rootScope.currentUser.userId) {
            return;
        }
        messageSvc.spam(conversation.startMessageId, $rootScope.currentUser.userId).then(function (data) {
            conversation.spamMessages += 1;
        });
    };

    $scope.spamMsg = function (message, conversation) {
        if (!$rootScope.currentUser.userId) {
            return;
        }
        messageSvc.spam(message.messageId, $rootScope.currentUser.userId).then(function (data) {
            message.spamCount += 1;
            conversation.spamMessages += 1;
        });
    };

    $scope.setMessageFile = function (file) {

        $scope.messageFile = file;
        var reader = new FileReader();
        reader.onload = function (e) {
            //compressAndShowImage(e.target.result, file, $scope);
            //compressAndShowImage1(e.target.result, file, $scope);

            //$(".img_file").append("img").prop("src", e.target.result);
            $scope.previewImage = e.target.result;
            $scope.$apply();
        }
        reader.readAsDataURL(file);

    };

    $scope.unsetMessageFile = function () {
        $scope.messageFile = 0;
    };

    $scope.addMessage = function (conversation) {
        var formScope = this;
        var message = this.message;
        console.log($scope.messageFile);
        if (!message && !$scope.messageFile) {
            $rootScope.showMessage('You can not post a blank message.');
            return;
        }
        if (!message) {
            message = " ";
        }
        if (!$scope.currentUser.userId) {
            $('#sign-in-modal').foundation('reveal', 'open');
            $rootScope.lastElement = $(event.target).find("input").get(0);
            var e = jQuery.Event("keydown");
            e.which = 13;
            // # Some key code value
            $rootScope.lastEvent = e;
            return false;
        }
        $scope.postMessage = 1;
        messageSvc.addToConversation(conversation.conversationId, {
            userid: $scope.currentUser.userId,
            nickname: $scope.currentUser.nickname,
            message: message
        }).then(function (data) {
                var messageId = data.messageId;
                if ($scope.messageFile) {

                    appSvc.uploadMedia($scope.messageFile, $scope.venueId + "/" + conversation.channelId + "/" + messageId).then(function (data) {
                        appSvc.updateMessageMedia(messageId, {
                            keyname: data.mediaKey,
                            category: "message",
                            type: $scope.messageFile.type
                        }).then(function (data) {
                                $rootScope.getMessages(conversation);
                                $scope.postMessage = 0;
                            }, function () {
                                $scope.postMessage = 0;
                            });
                    });
                }
                else {
                    $rootScope.getMessages(conversation);
                    $scope.postMessage = 0;
                }
                conversation.numMessages += 1;
                $("#choose_file_" + conversation.conversationId).val("");
                $scope.messageFile = 0;
                formScope.message = '';
            }, function () {
                $scope.postMessage = 0;
            });

        return false;
    };
});

function initialize() {
    var scope = angular.element(document).scope();
    scope.shareAvailable = true;
    scope.$apply(scope.$broadcast('MapLoaded'));
    scope.updateAddthis();
}

m.controller("MapCtrl", function ($scope, $rootScope, $timeout, $location) {
    function showMap() {
        if (!$rootScope.currentVenue && !$rootScope.currentVenue.latitude)
            return;
        if (typeof google == "undefined") return;
        var mapOptions = {
            zoom: 6,
            center: new google.maps.LatLng($rootScope.currentVenue.latitude, $rootScope.currentVenue.longitude),
            disableDefaultUI: true,
            mapTypeControl: true,
            zoomControl: true,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
        var marker = new google.maps.Marker({
            position: map.getCenter(),
            map: map,
            title: 'Click to zoom'
        });

        google.maps.event.addListener(marker, 'click', function () {
            map.setZoom(8);
            map.setCenter(marker.getPosition());
        });
    }

    $scope.allVenueMap = function () {
        if (!$rootScope.currentVenue && !$rootScope.currentVenue.latitude)
            return;
        if (!$rootScope.nearbyVenues) {
            return;
        }
        if (typeof google == "undefined") return;
        var mapOptions = {
            zoom: 10,
            center: new google.maps.LatLng($rootScope.currentVenue.latitude, $rootScope.currentVenue.longitude),
            disableDefaultUI: true,
            mapTypeControl: true,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var venuesMap = new google.maps.Map(document.getElementById('allVenuesMap'), mapOptions);
        for (var i = 0; i < $rootScope.nearbyVenues.length; i++) {
            var marker;
            if ($rootScope.nearbyVenues[i].venueId == $rootScope.currentVenue.venueId) {
                marker = new google.maps.Marker({
                    venueId: $rootScope.nearbyVenues[i].venueId,
                    position: new google.maps.LatLng($rootScope.nearbyVenues[i].latitude, $rootScope.nearbyVenues[i].longitude),
                    map: venuesMap,
                    title: $rootScope.nearbyVenues[i].name
                });
            }
            else {
                marker = new google.maps.Marker({
                    venueId: $rootScope.nearbyVenues[i].venueId,
                    position: new google.maps.LatLng($rootScope.nearbyVenues[i].latitude, $rootScope.nearbyVenues[i].longitude),
                    map: venuesMap,
                    title: $rootScope.nearbyVenues[i].name
                });
                marker.setIcon('http://maps.google.com/mapfiles/ms/icons/blue-dot.png');
                //marker.setIcon('  http://www.googlemapsmarkers.com/v1/07FAF6/');
            }
            google.maps.event.addListener(marker, 'click', function () {
                if($rootScope.currentVenue.venueId == this.venueId){
                    $('#map-modal').foundation('reveal', 'close');
                    $(".reveal-modal-bg").hide();
                }
                else{
                    $('#map-modal').foundation('reveal', 'close');
                    $location.path("/" + this.venueId);
                    $scope.$apply();
                }
            });
        }

        $('#map-modal').foundation('reveal', 'open');
        $('#map-modal').foundation('reveal', {
            opened: function () {
                google.maps.event.trigger(venuesMap, 'resize');
                venuesMap.setCenter(new google.maps.LatLng($rootScope.currentVenue.latitude, $rootScope.currentVenue.longitude));
            }
        });
    }

    $scope.$on("$routeChangeSuccess", function () {
        $timeout(showMap, 1000);
    });
    $scope.$on("MapLoaded", showMap);
});

function loadScript() {
    var script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = 'https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false&' +
        'callback=initialize';
    document.body.appendChild(script);
}

window.onload = loadScript;