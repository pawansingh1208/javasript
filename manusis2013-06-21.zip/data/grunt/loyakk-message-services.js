angular.module('loyakk-services').factory('messageSvc', function ($rootScope, appSvc, $http, $q) {
    var svc = {

        addToConversation: function (conversation_id, params) {
            if (!params) params = {};
            var deferred = $q.defer();
            var api_url = appSvc.baseUrlSecure + 'conversations/v3/' + conversation_id;
            $http.post(api_url, params).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    deferred.reject();
                });
            return deferred.promise;
        },

        getMessages: function (conversationId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrl + 'conversations/' + conversationId + '/messages';
            $http.get(api_url, {params: params}).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    deferred.reject();
                });
            return deferred.promise;
        },

        getMessageDetails: function (messageId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrl + 'messages/' + messageId;
            $http.get(api_url, {params: params}).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    deferred.reject();
                });
            return deferred.promise;
        },

        like: function (messageId, userId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrlSecure + 'messages/' + messageId + '/user/' + userId + '/like';
            $http.post(api_url, params).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    deferred.reject();
                });
            return deferred.promise;
        },

        spam: function (messageId, userId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrlSecure + 'messages/' + messageId + '/user/' + userId + '/spam';
            $http.post(api_url, params).success(function (data) {
                deferred.resolve(data.messages);
            }).error(function (data) {
                    deferred.reject();
                });
            return deferred.promise;
        },

        sendPrivateMessage: function (conversationId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrlSecure + 'conversations/' + conversationId + '/private';
            $http.post(api_url, params).success(function (data) {
                deferred.resolve(data.messages);
            }).error(function (data) {
                    deferred.reject();
                });
            return deferred.promise;
        },

        getPrivateMessage: function (userId, conversationId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrlSecure + 'messages/user/' + userId + '/conversation/' + conversationId + '/private';
            $http.get(api_url, {params: params}).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    deferred.reject();
                });
            return deferred.promise;
        },

        getPrivateMessageCount: function (userId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrlSecure + 'user/' + userId + '/newmessagecount';
            $http.get(api_url, {params: params}).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    deferred.reject();
                });
            return deferred.promise;
        },

        deleteMessage: function (userId, messageId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrlSecure + 'users/' + userId + '/message/' + messageId;
            $http.delete(api_url, {params: params}).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    deferred.reject();
                });
            return deferred.promise;
        },

        markPrivateMessageRead: function (userId, messageId, params) {
            var deferred = $q.defer();
            if (!params) params = {};
            var api_url = appSvc.baseUrlSecure + 'users/messages/markpmasread';
            $http.put(api_url, {params: params}).success(function (data) {
                deferred.resolve(data);
            }).error(function (data) {
                    deferred.reject();
                });
            return deferred.promise;
        },

        uploadMedia: function (params) {
            var deferred = $q.defer();
            var api_url = appSvc.baseUrl + 'media/upload';
            if (!params) params = {};
            $http.post(api_url, params).success(function (data) {
                deferred.resolve(data.messages);
            }).error(function (data) {
                    console.log(data);
                    deferred.reject();
                });
            return deferred.promise;
        },
        getPrivateChannelConvMessages: function(userId, conversationId, params){
            var deferred = $q.defer();
            var api_url = appSvc.baseUrlSecure + 'users/' + userId + '/conversation/' + conversationId + '/messages';
            if(!params) params = {};
            $http.get(api_url, {params:params}).success(function(data){
                deferred.resolve(data);
            }).error(function(data){
                    deferred.reject();
            });
            return deferred.promise;
        }
    };
    return svc;
});
